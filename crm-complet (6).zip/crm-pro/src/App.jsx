import { useState, useCallback, useEffect } from 'react'
import Modal from './Modal.jsx'
import DetailPanel from './DetailPanel.jsx'
import PrintSheet from './PrintSheet.jsx'
import CarteTerritoire from './CarteTerritoire.jsx'
import * as D from './data.js'
import * as API from './api.js'

// ─── icons ───────────────────────────────────────────────────────────────────
const IcoDash    = () => <svg viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="6" height="6" rx="1" fill="currentColor" opacity=".7"/><rect x="9" y="1" width="6" height="6" rx="1" fill="currentColor" opacity=".7"/><rect x="1" y="9" width="6" height="6" rx="1" fill="currentColor" opacity=".4"/><rect x="9" y="9" width="6" height="6" rx="1" fill="currentColor" opacity=".4"/></svg>
const IcoCont    = () => <svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="5" r="3" fill="currentColor" opacity=".7"/><path d="M2 13c0-3.3 2.7-6 6-6s6 2.7 6 6" stroke="currentColor" strokeWidth="1.5" fill="none" opacity=".7"/></svg>
const IcoPipe    = () => <svg viewBox="0 0 16 16" fill="none"><rect x="1" y="4" width="3" height="10" rx="1" fill="currentColor" opacity=".5"/><rect x="6" y="2" width="3" height="12" rx="1" fill="currentColor" opacity=".7"/><rect x="11" y="6" width="3" height="8" rx="1" fill="currentColor" opacity=".5"/></svg>
const IcoEnt     = () => <svg viewBox="0 0 16 16" fill="none"><rect x="2" y="5" width="12" height="9" rx="1" stroke="currentColor" strokeWidth="1.2" fill="none" opacity=".7"/><path d="M5 5V3a1 1 0 011-1h4a1 1 0 011 1v2" stroke="currentColor" strokeWidth="1.2" fill="none" opacity=".7"/></svg>
const IcoAct     = () => <svg viewBox="0 0 16 16" fill="none"><rect x="2" y="2" width="12" height="12" rx="2" stroke="currentColor" strokeWidth="1.2" fill="none" opacity=".7"/><path d="M5 8h6M8 5v6" stroke="currentColor" strokeWidth="1.2" opacity=".7"/></svg>
const IcoCal     = () => <svg viewBox="0 0 16 16" fill="none"><rect x="1" y="3" width="14" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.2" fill="none" opacity=".7"/><path d="M1 7h14" stroke="currentColor" strokeWidth="1" opacity=".5"/><path d="M5 1v4M11 1v4" stroke="currentColor" strokeWidth="1.2" opacity=".7"/><circle cx="5" cy="11" r="1" fill="currentColor" opacity=".6"/><circle cx="8" cy="11" r="1" fill="currentColor" opacity=".6"/></svg>
const IcoMap     = () => <svg viewBox="0 0 16 16" fill="none"><path d="M6 2L2 4v10l4-2 4 2 4-2V2l-4 2-4-2z" stroke="currentColor" strokeWidth="1.2" fill="none" opacity=".7"/><path d="M6 2v10M10 4v10" stroke="currentColor" strokeWidth="1" opacity=".5"/></svg>
const IcoDevis   = () => <svg viewBox="0 0 16 16" fill="none"><rect x="2" y="1" width="12" height="14" rx="1" stroke="currentColor" strokeWidth="1.2" fill="none" opacity=".7"/><path d="M5 5h6M5 8h6M5 11h4" stroke="currentColor" strokeWidth="1.1" opacity=".7"/></svg>
const IcoFac     = () => <svg viewBox="0 0 16 16" fill="none"><rect x="2" y="1" width="12" height="14" rx="1" stroke="currentColor" strokeWidth="1.2" fill="none" opacity=".7"/><path d="M5 5h6M5 8h3" stroke="currentColor" strokeWidth="1.1" opacity=".7"/><circle cx="11" cy="11" r="3" fill="currentColor" opacity=".4"/><path d="M10 11h2M11 10v2" stroke="currentColor" strokeWidth="1" opacity=".9"/></svg>

const PAGES = [
  { id:'dashboard',   label:'Tableau de bord',   Icon:IcoDash,  btn:'+ Nouveau contact' },
  { id:'contacts',    label:'Contacts',           Icon:IcoCont,  btn:'+ Nouveau contact' },
  { id:'pipeline',    label:'Pipeline',           Icon:IcoPipe,  btn:'+ Nouveau deal' },
  { id:'entreprises', label:'Entreprises',        Icon:IcoEnt,   btn:'+ Nouvelle entreprise' },
  { id:'activites',   label:'Activités',          Icon:IcoAct,   btn:'+ Nouvelle activité' },
  { id:'planning',    label:'Planning visites',   Icon:IcoCal,   btn:'+ Nouvelle visite' },
  { id:'carte',       label:'Carte territoire',   Icon:IcoMap,   btn:'Zone Tréfumel' },
  { id:'devis',       label:'Devis',              Icon:IcoDevis, btn:'+ Nouveau devis' },
  { id:'factures',    label:'Factures',           Icon:IcoFac,   btn:'+ Nouvelle facture' },
]

const STAGES = ['Prospection','Qualifié','Proposition','Négociation','Gagné']
const STAGE_COLORS = { Prospection:'bgr', Qualifié:'bb', Proposition:'bb', Négociation:'ba', Gagné:'bg' }
const STAGE_BAR    = { Prospection:'#888780', Qualifié:'#378ADD', Proposition:'#534AB7', Négociation:'#BA7517', Gagné:'#1D9E75' }

export default function App() {
  const [page, setPage]         = useState('dashboard')
  const [contacts, setContacts] = useState(D.contacts)
  const [ents, setEnts]         = useState(D.entreprises)
  const [deals, setDeals]       = useState(D.deals)
  const [acts, setActs]         = useState(D.activites)
  const [vis, setVis]           = useState(D.visits)
  const [devs, setDevs]         = useState(D.devisData)
  const [facs, setFacs]         = useState(D.facturesData)
  const [modal, setModal]       = useState(null)
  const [detail, setDetail]     = useState(null)
  const [printJob, setPrintJob] = useState(null)
  const [contactFilter, setContactFilter] = useState('tous')
  const [devisFilter, setDevisFilter]     = useState('tous')
  const [facFilter, setFacFilter]         = useState('tous')
  const [calYear, setCalYear]   = useState(new Date().getFullYear())
  const [calMonth, setCalMonth] = useState(new Date().getMonth())
  const [syncState, setSyncState] = useState('idle') // idle|loading|saving|saved|error
  const [dbError, setDbError]     = useState(null)

  const getEnt  = useCallback(id => ents.find(e=>e.id===id)||{nom:'—'}, [ents])
  const getCont = useCallback(id => contacts.find(c=>c.id===id)||{prenom:'',nom:'—'}, [contacts])

  // ── Chargement initial depuis MySQL ─────────────────────────────────────────
  useEffect(() => {
    loadAll()
  }, [])

  const loadAll = async () => {
    setSyncState('loading')
    setDbError(null)
    try {
      const [c, e, d, a, v, dv, f] = await Promise.all([
        API.getContacts(),
        API.getEntreprises(),
        API.getDeals(),
        API.getActivites(),
        API.getVisites(),
        API.getDevis(),
        API.getFactures(),
      ])
      // Adapter les champs DB → format interne UI
      setContacts(c.map(x => ({ ...x, tel: x.telephone, resp: x.responsable, av: (x.prenom[0]||'?')+(x.nom[0]||'?'), avc: ['ab','at','ap','ac','ak'][x.id%5] })))
      setEnts(e)
      setDeals(d.map(x => ({ ...x, prob: x.probabilite, resp: x.responsable, date_cloture: x.date_cloture?.split('T')[0]||'' })))
      setActs(a.map(x => ({ ...x, date: x.date_activite?.split('T')[0]||'', resp: x.responsable })))
      setVis(v.map(x => ({ ...x, date: x.date_visite?.split('T')[0]||'', resp: x.responsable })))
      setDevs(dv.map(x => ({ ...x, ht: parseFloat(x.montant_ht)||0, date: x.date_emission?.split('T')[0]||'', validite: x.date_validite?.split('T')[0]||'', items: x.items||[] })))
      setFacs(f.map(x => ({ ...x, ht: parseFloat(x.montant_ht)||0, tva: parseFloat(x.taux_tva)||20, emission: x.date_emission?.split('T')[0]||'', echeance: x.date_echeance?.split('T')[0]||'' })))
      setSyncState('idle')
    } catch (err) {
      setDbError(err.message)
      setSyncState('error')
    }
  }

  // ── Sync / Rafraîchir depuis MySQL ──────────────────────────────────────────
  const handleSync = () => loadAll()

  // ── Top button handler ──────────────────────────────────────────────────────
  const handleTopBtn = () => {
    const map = { dashboard:'contact', contacts:'contact', pipeline:'deal', entreprises:'ent', activites:'act', planning:'visit', devis:'devis', factures:'fac' }
    setModal(map[page])
  }

  // ── Save handlers → appels API réels ───────────────────────────────────────
  const saveContact = async (f) => {
    try {
      const avcs = ['ab','at','ap','ac','ak']
      const created = await API.createContact({ prenom:f.prenom, nom:f.nom, email:f.email, telephone:f.tel, poste:f.poste, statut:f.statut||'Prospect', responsable:f.resp, entreprise_id:parseInt(f.entreprise_id)||null })
      setContacts(p=>[...p,{ ...created, tel:created.telephone, resp:created.responsable, av:(created.prenom[0]||'?')+(created.nom[0]||'?'), avc:avcs[created.id%5] }])
      setModal(null)
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const saveEnt = async (f) => {
    try {
      const created = await API.createEntreprise({ nom:f.nom, secteur:f.secteur, statut:f.statut||'Prospect', ville:f.ville })
      setEnts(p=>[...p, created])
      setModal(null)
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const saveDeal = async (f) => {
    try {
      const created = await API.createDeal({ nom:f.nom, valeur:parseFloat(f.valeur)||0, probabilite:parseInt(f.prob)||0, etape:f.etape||'Prospection', contact_id:parseInt(f.contact_id)||null, entreprise_id:parseInt(f.entreprise_id)||null, responsable:f.resp, date_cloture:f.date_cloture||null })
      setDeals(p=>[...p,{ ...created, prob:created.probabilite, resp:created.responsable }])
      setModal(null)
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const saveAct = async (f) => {
    try {
      const created = await API.createActivite({ type:f.type||'Email', titre:f.titre, description:f.desc, statut:f.statut||'Planifiée', date_activite:f.date, heure:f.heure||'09:00', contact_id:parseInt(f.contact_id)||null, responsable:f.resp })
      setActs(p=>[...p,{ ...created, date:created.date_activite?.split('T')[0]||'', resp:created.responsable }])
      setModal(null)
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const saveVisit = async (f) => {
    try {
      const created = await API.createVisite({ date_visite:f.date, heure:f.heure||'10:00', contact_id:parseInt(f.contact_id)||null, entreprise_id:parseInt(f.entreprise_id)||null, type:f.type||'Visite client', lieu:f.lieu, statut:f.statut||'En attente', responsable:f.resp, notes:f.notes })
      setVis(p=>[...p,{ ...created, date:created.date_visite?.split('T')[0]||'', resp:created.responsable }])
      setModal(null)
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const saveDevis = async (f) => {
    try {
      const qty = parseFloat(f.qty)||1, pu = parseFloat(f.pu)||0
      const today = new Date().toISOString().split('T')[0]
      const created = await API.createDevis({ entreprise_id:parseInt(f.entreprise_id), statut:'En attente', date_emission:today, date_validite:f.validite, items:[{ desc:f.desc, qty, pu }] })
      setDevs(p=>[...p,{ ...created, ht:parseFloat(created.montant_ht)||qty*pu, date:today, validite:f.validite, items:created.items||[{desc:f.desc,qty,pu}] }])
      setModal(null)
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const saveFac = async (f) => {
    try {
      const created = await API.createFacture({ entreprise_id:parseInt(f.entreprise_id), devis_id:parseInt(f.devis_id)||null, statut:'En attente', date_emission:f.emission, date_echeance:f.echeance, montant_ht:parseFloat(f.ht)||0, taux_tva:parseFloat(f.tva)||20 })
      setFacs(p=>[...p,{ ...created, ht:parseFloat(created.montant_ht)||0, tva:parseFloat(created.taux_tva)||20, emission:created.date_emission?.split('T')[0]||'', echeance:created.date_echeance?.split('T')[0]||'' }])
      setModal(null)
    } catch (err) { alert('Erreur : '+err.message) }
  }

  // ── Edit state ──────────────────────────────────────────────────────────────
  const [editItem, setEditItem] = useState(null) // { type, data }

  const openEdit = (type, data) => setEditItem({ type, data })
  const closeEdit = () => setEditItem(null)

  // ── Update handlers ─────────────────────────────────────────────────────────
  const updateContact = async (f) => {
    try {
      const avcs = ['ab','at','ap','ac','ak']
      const updated = await API.updateContact(f.id, { prenom:f.prenom, nom:f.nom, email:f.email, telephone:f.tel, poste:f.poste, statut:f.statut, responsable:f.resp, entreprise_id:parseInt(f.entreprise_id)||null })
      setContacts(p=>p.map(x=>x.id===f.id ? { ...updated, tel:updated.telephone, resp:updated.responsable, av:(updated.prenom[0]||'?')+(updated.nom[0]||'?'), avc:avcs[updated.id%5] } : x))
      setDetail(null); closeEdit()
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const updateEnt = async (f) => {
    try {
      const updated = await API.updateEntreprise(f.id, { nom:f.nom, secteur:f.secteur, statut:f.statut, ville:f.ville })
      setEnts(p=>p.map(x=>x.id===f.id ? { ...x, ...updated } : x))
      setDetail(null); closeEdit()
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const updateDeal = async (f) => {
    try {
      const updated = await API.updateDeal(f.id, { nom:f.nom, valeur:parseFloat(f.valeur)||0, probabilite:parseInt(f.prob)||0, etape:f.etape, contact_id:parseInt(f.contact_id)||null, entreprise_id:parseInt(f.entreprise_id)||null, responsable:f.resp, date_cloture:f.date_cloture||null })
      setDeals(p=>p.map(x=>x.id===f.id ? { ...updated, prob:updated.probabilite, resp:updated.responsable } : x))
      setDetail(null); closeEdit()
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const updateAct = async (f) => {
    try {
      const updated = await API.updateActivite(f.id, { type:f.type, titre:f.titre, description:f.desc, statut:f.statut, date_activite:f.date, heure:f.heure, contact_id:parseInt(f.contact_id)||null, responsable:f.resp })
      setActs(p=>p.map(x=>x.id===f.id ? { ...updated, date:updated.date_activite?.split('T')[0]||'', resp:updated.responsable } : x))
      setDetail(null); closeEdit()
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const updateVisite = async (f) => {
    try {
      const updated = await API.updateVisite(f.id, { date_visite:f.date, heure:f.heure, contact_id:parseInt(f.contact_id)||null, entreprise_id:parseInt(f.entreprise_id)||null, type:f.type, lieu:f.lieu, statut:f.statut, responsable:f.resp, notes:f.notes })
      setVis(p=>p.map(x=>x.id===f.id ? { ...updated, date:updated.date_visite?.split('T')[0]||'', resp:updated.responsable } : x))
      setDetail(null); closeEdit()
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const updateFacStatut = async (id, statut) => {
    try {
      await API.updateFacture(id, { statut })
      setFacs(p=>p.map(x=>x.id===id ? { ...x, statut } : x))
    } catch (err) { alert('Erreur : '+err.message) }
  }

  const today = new Date().toISOString().split('T')[0]
  const m30 = new Date(); m30.setDate(m30.getDate()+30)
  const todayPlus30 = m30.toISOString().split('T')[0]

  // ── Pages ────────────────────────────────────────────────────────────────────
  const pages = {
    dashboard:   <Dashboard contacts={contacts} deals={deals} vis={vis} devs={devs} acts={acts} getEnt={getEnt} getCont={getCont} setPrintJob={setPrintJob} />,
    contacts:    <Contacts contacts={contacts} setContacts={setContacts} filter={contactFilter} setFilter={setContactFilter} getEnt={getEnt} setDetail={setDetail} setPrintJob={setPrintJob} openEdit={openEdit} />,
    pipeline:    <Pipeline deals={deals} setDeals={setDeals} getEnt={getEnt} getCont={getCont} setDetail={setDetail} setPrintJob={setPrintJob} openEdit={openEdit} />,
    entreprises: <Entreprises ents={ents} setEnts={setEnts} contacts={contacts} deals={deals} setDetail={setDetail} openEdit={openEdit} />,
    activites:   <Activites acts={acts} setActs={setActs} getCont={getCont} openEdit={openEdit} />,
    planning:    <Planning vis={vis} setVis={setVis} calYear={calYear} calMonth={calMonth} setCalYear={setCalYear} setCalMonth={setCalMonth} getCont={getCont} getEnt={getEnt} setDetail={setDetail} setModal={setModal} setPrintJob={setPrintJob} openEdit={openEdit} />,
    carte:       <CarteTerritoire contacts={contacts} vis={vis} getEnt={getEnt} ents={ents} />,
    devis:       <Devis devs={devs} filter={devisFilter} setFilter={setDevisFilter} getEnt={getEnt} setDetail={setDetail} setPrintJob={setPrintJob} openEdit={openEdit} />,
    factures:    <Factures facs={facs} setFacs={setFacs} filter={facFilter} setFilter={setFacFilter} getEnt={getEnt} setDetail={setDetail} devs={devs} setPrintJob={setPrintJob} openEdit={openEdit} />,
  }

  const pageInfo = PAGES.find(p=>p.id===page)

  // ── Écran d'erreur connexion ──────────────────────────────────────────────
  if (syncState === 'error' && dbError) {
    return (
      <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh',background:'var(--bg2)',padding:24}}>
        <div style={{background:'var(--bg1)',border:'0.5px solid var(--border1)',borderRadius:'var(--radius-lg)',padding:32,maxWidth:520,width:'100%'}}>
          <div style={{fontSize:20,fontWeight:500,marginBottom:6}}>Connexion impossible</div>
          <div style={{fontSize:13,color:'var(--text2)',marginBottom:20}}>Le CRM n'arrive pas à joindre le backend MySQL.</div>

          <div style={{background:'var(--bg2)',borderRadius:'var(--radius-md)',padding:14,marginBottom:20,fontSize:12,fontFamily:'monospace',color:'var(--red-text)',whiteSpace:'pre-wrap',wordBreak:'break-all'}}>
            {dbError}
          </div>

          <div style={{fontSize:13,fontWeight:500,marginBottom:10}}>Causes fréquentes :</div>
          <div style={{fontSize:12,color:'var(--text2)',lineHeight:2,marginBottom:20}}>
            {[
              ['Le backend n\'est pas démarré', 'cd crm-backend && npm start'],
              ['VITE_API_URL incorrect', `Actuellement : ${API.API_BASE}`],
              ['Port bloqué ou pare-feu', 'Vérifiez que le port 4000 est ouvert'],
              ['Problème CORS', 'Le backend doit autoriser l\'origine du frontend'],
              ['MySQL non démarré', 'Vérifiez votre serveur MySQL et le fichier .env'],
            ].map(([label, detail]) => (
              <div key={label} style={{display:'flex',gap:8,marginBottom:4}}>
                <span style={{color:'var(--red-text)'}}>✕</span>
                <span><b style={{fontWeight:500,color:'var(--text1)'}}>{label}</b><br/>
                <span style={{fontFamily:'monospace',fontSize:11}}>{detail}</span></span>
              </div>
            ))}
          </div>

          <div style={{fontSize:12,color:'var(--text2)',marginBottom:16,padding:'10px 12px',background:'var(--bg2)',borderRadius:'var(--radius-md)'}}>
            <b style={{fontWeight:500,color:'var(--text1)'}}>URL API configurée :</b> <code style={{fontFamily:'monospace'}}>{API.API_BASE}</code><br/>
            Pour changer : modifiez <code style={{fontFamily:'monospace'}}>VITE_API_URL</code> dans <code style={{fontFamily:'monospace'}}>crm-pro/.env</code>
          </div>

          <div style={{display:'flex',gap:10}}>
            <button className="btn btn-p" style={{flex:1}} onClick={loadAll}>
              ↻ Réessayer
            </button>
            <button className="btn" style={{flex:1}} onClick={()=>{setSyncState('idle');setDbError(null)}}>
              Continuer sans MySQL
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="app">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="logo">CRM Pro</div>
        {PAGES.map(({id,label,Icon})=>(
          <div key={id} className={`nav-item${page===id?' active':''}`} onClick={()=>setPage(id)}>
            <Icon />{label}
          </div>
        ))}
      </div>

      {/* Main */}
      <div className="main">
        <div className="topbar">
          <h2>{pageInfo?.label}</h2>
          {dbError && (
            <span style={{fontSize:11,color:'var(--red-text)',whiteSpace:'nowrap',maxWidth:200,overflow:'hidden',textOverflow:'ellipsis'}} title={dbError}>
              ✕ MySQL : {dbError}
            </span>
          )}
          {syncState === 'loading' && (
            <span style={{fontSize:11,color:'var(--text2)',whiteSpace:'nowrap',display:'flex',alignItems:'center',gap:5}}>
              <span style={{display:'inline-block',width:10,height:10,borderRadius:'50%',border:'1.5px solid var(--text2)',borderTopColor:'transparent',animation:'spin .7s linear infinite'}}/>
              Chargement MySQL…
            </span>
          )}
          {syncState === 'idle' && !dbError && (
            <span style={{fontSize:11,color:'var(--text3)',whiteSpace:'nowrap'}}>✓ MySQL connecté</span>
          )}
          <button
            className="btn"
            onClick={handleSync}
            disabled={syncState === 'loading'}
            style={{display:'flex',alignItems:'center',gap:6,opacity:syncState==='loading'?.6:1}}
            title="Recharger les données depuis MySQL"
          >
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
              <path d="M14 8A6 6 0 1 1 8 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              <path d="M8 2l2.5 2.5L8 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Actualiser
          </button>
          <button className="btn btn-p" onClick={handleTopBtn}>{pageInfo?.btn}</button>
        </div>
        <div className="content">{pages[page]}</div>
      </div>

      {/* Detail panel */}
      <DetailPanel open={!!detail} onClose={()=>setDetail(null)}>{detail}</DetailPanel>

      {/* Modals */}
      <FormModal open={modal==='contact'} onClose={()=>setModal(null)} title="Nouveau contact" onSave={saveContact} ents={ents} contacts={contacts} today={today}>
        {(f,set)=>(
          <>
            <div className="fr2"><div className="fr"><label className="fl">Prénom</label><input className="fi" value={f.prenom||''} onChange={e=>set({...f,prenom:e.target.value})} placeholder="Marie"/></div><div className="fr"><label className="fl">Nom</label><input className="fi" value={f.nom||''} onChange={e=>set({...f,nom:e.target.value})} placeholder="Dupont"/></div></div>
            <div className="fr"><label className="fl">Email</label><input className="fi" type="email" value={f.email||''} onChange={e=>set({...f,email:e.target.value})} placeholder="marie@société.fr"/></div>
            <div className="fr2"><div className="fr"><label className="fl">Téléphone</label><input className="fi" value={f.tel||''} onChange={e=>set({...f,tel:e.target.value})} placeholder="+33 6 ..."/></div><div className="fr"><label className="fl">Entreprise</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Poste</label><input className="fi" value={f.poste||''} onChange={e=>set({...f,poste:e.target.value})} placeholder="Directrice Marketing"/></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'Prospect'} onChange={e=>set({...f,statut:e.target.value})}><option>Prospect</option><option>Actif</option><option>Client</option><option>Inactif</option></select></div></div>
            <div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})} placeholder="Thomas"/></div>
          </>
        )}
      </FormModal>

      <FormModal open={modal==='ent'} onClose={()=>setModal(null)} title="Nouvelle entreprise" onSave={saveEnt}>
        {(f,set)=>(
          <>
            <div className="fr"><label className="fl">Nom de l'entreprise</label><input className="fi" value={f.nom||''} onChange={e=>set({...f,nom:e.target.value})} placeholder="Renault"/></div>
            <div className="fr2"><div className="fr"><label className="fl">Secteur</label><input className="fi" value={f.secteur||''} onChange={e=>set({...f,secteur:e.target.value})} placeholder="Automobile"/></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'Prospect'} onChange={e=>set({...f,statut:e.target.value})}><option>Prospect</option><option>Actif</option><option>Inactif</option></select></div></div>
            <div className="fr"><label className="fl">Ville</label><input className="fi" value={f.ville||''} onChange={e=>set({...f,ville:e.target.value})} placeholder="Paris"/></div>
          </>
        )}
      </FormModal>

      <FormModal open={modal==='deal'} onClose={()=>setModal(null)} title="Nouveau deal" onSave={saveDeal} ents={ents} contacts={contacts}>
        {(f,set)=>(
          <>
            <div className="fr"><label className="fl">Nom du deal</label><input className="fi" value={f.nom||''} onChange={e=>set({...f,nom:e.target.value})} placeholder="Contrat SaaS 2026"/></div>
            <div className="fr2"><div className="fr"><label className="fl">Valeur (€)</label><input className="fi" type="number" value={f.valeur||''} onChange={e=>set({...f,valeur:e.target.value})} placeholder="45000"/></div><div className="fr"><label className="fl">Probabilité (%)</label><input className="fi" type="number" min="0" max="100" value={f.prob||''} onChange={e=>set({...f,prob:e.target.value})} placeholder="60"/></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Étape</label><select className="fi" value={f.etape||'Prospection'} onChange={e=>set({...f,etape:e.target.value})}>{STAGES.concat(['Perdu']).map(s=><option key={s}>{s}</option>)}</select></div><div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})} placeholder="Thomas"/></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Contact</label><select className="fi" value={f.contact_id||''} onChange={e=>set({...f,contact_id:e.target.value})}><option value="">—</option>{contacts.map(c=><option key={c.id} value={c.id}>{c.prenom} {c.nom}</option>)}</select></div><div className="fr"><label className="fl">Entreprise</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div></div>
            <div className="fr"><label className="fl">Date de clôture</label><input className="fi" type="date" value={f.date_cloture||''} onChange={e=>set({...f,date_cloture:e.target.value})}/></div>
          </>
        )}
      </FormModal>

      <FormModal open={modal==='act'} onClose={()=>setModal(null)} title="Nouvelle activité" onSave={saveAct} contacts={contacts} today={today}>
        {(f,set)=>(
          <>
            <div className="fr2"><div className="fr"><label className="fl">Type</label><select className="fi" value={f.type||'Email'} onChange={e=>set({...f,type:e.target.value})}>{['Email','Appel','Réunion','Tâche','Note'].map(t=><option key={t}>{t}</option>)}</select></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'Planifiée'} onChange={e=>set({...f,statut:e.target.value})}><option>Planifiée</option><option>Terminée</option><option>Annulée</option></select></div></div>
            <div className="fr"><label className="fl">Titre</label><input className="fi" value={f.titre||''} onChange={e=>set({...f,titre:e.target.value})} placeholder="Appel de suivi"/></div>
            <div className="fr2"><div className="fr"><label className="fl">Date</label><input className="fi" type="date" value={f.date||today} onChange={e=>set({...f,date:e.target.value})}/></div><div className="fr"><label className="fl">Heure</label><input className="fi" type="time" value={f.heure||'09:00'} onChange={e=>set({...f,heure:e.target.value})}/></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Contact</label><select className="fi" value={f.contact_id||''} onChange={e=>set({...f,contact_id:e.target.value})}><option value="">—</option>{contacts.map(c=><option key={c.id} value={c.id}>{c.prenom} {c.nom}</option>)}</select></div><div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})} placeholder="Thomas"/></div></div>
            <div className="fr"><label className="fl">Description</label><textarea className="fi" rows="2" value={f.desc||''} onChange={e=>set({...f,desc:e.target.value})} placeholder="Notes..."/></div>
          </>
        )}
      </FormModal>

      <FormModal open={modal==='visit'} onClose={()=>setModal(null)} title="Nouvelle visite" onSave={saveVisit} contacts={contacts} ents={ents} today={today}>
        {(f,set)=>(
          <>
            <div className="fr2"><div className="fr"><label className="fl">Date</label><input className="fi" type="date" value={f.date||today} onChange={e=>set({...f,date:e.target.value})}/></div><div className="fr"><label className="fl">Heure</label><input className="fi" type="time" value={f.heure||'10:00'} onChange={e=>set({...f,heure:e.target.value})}/></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Contact</label><select className="fi" value={f.contact_id||''} onChange={e=>set({...f,contact_id:e.target.value})}><option value="">—</option>{contacts.map(c=><option key={c.id} value={c.id}>{c.prenom} {c.nom}</option>)}</select></div><div className="fr"><label className="fl">Entreprise</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Type</label><select className="fi" value={f.type||'Visite client'} onChange={e=>set({...f,type:e.target.value})}>{['Visite client','Démo','Prospection','Autre'].map(t=><option key={t}>{t}</option>)}</select></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'En attente'} onChange={e=>set({...f,statut:e.target.value})}><option>Confirmée</option><option>En attente</option><option>Annulée</option></select></div></div>
            <div className="fr"><label className="fl">Lieu</label><input className="fi" value={f.lieu||''} onChange={e=>set({...f,lieu:e.target.value})} placeholder="12 rue de la Paix, Paris"/></div>
            <div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})} placeholder="Thomas"/></div>
            <div className="fr"><label className="fl">Notes</label><textarea className="fi" rows="2" value={f.notes||''} onChange={e=>set({...f,notes:e.target.value})} placeholder="Objectifs..."/></div>
          </>
        )}
      </FormModal>

      <FormModal open={modal==='devis'} onClose={()=>setModal(null)} title="Nouveau devis" onSave={saveDevis} ents={ents} today={today}>
        {(f,set)=>(
          <>
            <div className="fr2"><div className="fr"><label className="fl">Client</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div><div className="fr"><label className="fl">Validité</label><input className="fi" type="date" value={f.validite||todayPlus30} onChange={e=>set({...f,validite:e.target.value})}/></div></div>
            <div className="fr"><label className="fl">Description</label><input className="fi" value={f.desc||''} onChange={e=>set({...f,desc:e.target.value})} placeholder="Licence SaaS annuelle"/></div>
            <div className="fr2"><div className="fr"><label className="fl">Quantité</label><input className="fi" type="number" value={f.qty||1} onChange={e=>set({...f,qty:e.target.value})}/></div><div className="fr"><label className="fl">Prix unitaire HT (€)</label><input className="fi" type="number" value={f.pu||''} onChange={e=>set({...f,pu:e.target.value})} placeholder="45000"/></div></div>
          </>
        )}
      </FormModal>

      <FormModal open={modal==='fac'} onClose={()=>setModal(null)} title="Nouvelle facture" onSave={saveFac} ents={ents} devs={devs} today={today}>
        {(f,set)=>(
          <>
            <div className="fr2"><div className="fr"><label className="fl">Client</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div><div className="fr"><label className="fl">Devis associé</label><select className="fi" value={f.devis_id||''} onChange={e=>set({...f,devis_id:e.target.value})}><option value="">Aucun</option>{devs.map(d=><option key={d.id} value={d.id}>{d.ref}</option>)}</select></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Date d'émission</label><input className="fi" type="date" value={f.emission||today} onChange={e=>set({...f,emission:e.target.value})}/></div><div className="fr"><label className="fl">Date d'échéance</label><input className="fi" type="date" value={f.echeance||todayPlus30} onChange={e=>set({...f,echeance:e.target.value})}/></div></div>
            <div className="fr2"><div className="fr"><label className="fl">Montant HT (€)</label><input className="fi" type="number" value={f.ht||''} onChange={e=>set({...f,ht:e.target.value})} placeholder="45000"/></div><div className="fr"><label className="fl">TVA (%)</label><input className="fi" type="number" value={f.tva||20} onChange={e=>set({...f,tva:e.target.value})}/></div></div>
          </>
        )}
      </FormModal>

      {/* Print sheet */}
      {printJob && (
        <PrintSheet
          type={printJob.type}
          data={{ ...printJob.data, getEnt, getCont }}
          onClose={() => setPrintJob(null)}
        />
      )}

      {/* ── EDIT MODALS ─────────────────────────────────────────────────── */}

      {/* Edit Contact */}
      {editItem?.type === 'contact' && (
        <EditModal title="Modifier le contact" onClose={closeEdit} onSave={updateContact} initial={editItem.data}>
          {(f,set)=>(
            <>
              <div className="fr2"><div className="fr"><label className="fl">Prénom</label><input className="fi" value={f.prenom||''} onChange={e=>set({...f,prenom:e.target.value})}/></div><div className="fr"><label className="fl">Nom</label><input className="fi" value={f.nom||''} onChange={e=>set({...f,nom:e.target.value})}/></div></div>
              <div className="fr"><label className="fl">Email</label><input className="fi" type="email" value={f.email||''} onChange={e=>set({...f,email:e.target.value})}/></div>
              <div className="fr2"><div className="fr"><label className="fl">Téléphone</label><input className="fi" value={f.tel||''} onChange={e=>set({...f,tel:e.target.value})}/></div><div className="fr"><label className="fl">Entreprise</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div></div>
              <div className="fr2"><div className="fr"><label className="fl">Poste</label><input className="fi" value={f.poste||''} onChange={e=>set({...f,poste:e.target.value})}/></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'Prospect'} onChange={e=>set({...f,statut:e.target.value})}><option>Prospect</option><option>Actif</option><option>Client</option><option>Inactif</option></select></div></div>
              <div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})}/></div>
            </>
          )}
        </EditModal>
      )}

      {/* Edit Entreprise */}
      {editItem?.type === 'ent' && (
        <EditModal title="Modifier l'entreprise" onClose={closeEdit} onSave={updateEnt} initial={editItem.data}>
          {(f,set)=>(
            <>
              <div className="fr"><label className="fl">Nom</label><input className="fi" value={f.nom||''} onChange={e=>set({...f,nom:e.target.value})}/></div>
              <div className="fr2"><div className="fr"><label className="fl">Secteur</label><input className="fi" value={f.secteur||''} onChange={e=>set({...f,secteur:e.target.value})}/></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'Prospect'} onChange={e=>set({...f,statut:e.target.value})}><option>Prospect</option><option>Actif</option><option>Inactif</option></select></div></div>
              <div className="fr"><label className="fl">Ville</label><input className="fi" value={f.ville||''} onChange={e=>set({...f,ville:e.target.value})}/></div>
              <div className="fr"><label className="fl">Site web</label><input className="fi" value={f.site_web||''} onChange={e=>set({...f,site_web:e.target.value})} placeholder="https://..."/></div>
            </>
          )}
        </EditModal>
      )}

      {/* Edit Deal */}
      {editItem?.type === 'deal' && (
        <EditModal title="Modifier le deal" onClose={closeEdit} onSave={updateDeal} initial={editItem.data}>
          {(f,set)=>(
            <>
              <div className="fr"><label className="fl">Nom du deal</label><input className="fi" value={f.nom||''} onChange={e=>set({...f,nom:e.target.value})}/></div>
              <div className="fr2"><div className="fr"><label className="fl">Valeur (€)</label><input className="fi" type="number" value={f.valeur||''} onChange={e=>set({...f,valeur:e.target.value})}/></div><div className="fr"><label className="fl">Probabilité (%)</label><input className="fi" type="number" min="0" max="100" value={f.prob||''} onChange={e=>set({...f,prob:e.target.value})}/></div></div>
              <div className="fr2"><div className="fr"><label className="fl">Étape</label><select className="fi" value={f.etape||'Prospection'} onChange={e=>set({...f,etape:e.target.value})}>{STAGES.concat(['Perdu']).map(s=><option key={s}>{s}</option>)}</select></div><div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})}/></div></div>
              <div className="fr2"><div className="fr"><label className="fl">Contact</label><select className="fi" value={f.contact_id||''} onChange={e=>set({...f,contact_id:e.target.value})}><option value="">—</option>{contacts.map(c=><option key={c.id} value={c.id}>{c.prenom} {c.nom}</option>)}</select></div><div className="fr"><label className="fl">Entreprise</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div></div>
              <div className="fr"><label className="fl">Date de clôture</label><input className="fi" type="date" value={f.date_cloture||''} onChange={e=>set({...f,date_cloture:e.target.value})}/></div>
            </>
          )}
        </EditModal>
      )}

      {/* Edit Activité */}
      {editItem?.type === 'act' && (
        <EditModal title="Modifier l'activité" onClose={closeEdit} onSave={updateAct} initial={editItem.data}>
          {(f,set)=>(
            <>
              <div className="fr2"><div className="fr"><label className="fl">Type</label><select className="fi" value={f.type||'Email'} onChange={e=>set({...f,type:e.target.value})}>{['Email','Appel','Réunion','Tâche','Note'].map(t=><option key={t}>{t}</option>)}</select></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'Planifiée'} onChange={e=>set({...f,statut:e.target.value})}><option>Planifiée</option><option>Terminée</option><option>Annulée</option></select></div></div>
              <div className="fr"><label className="fl">Titre</label><input className="fi" value={f.titre||''} onChange={e=>set({...f,titre:e.target.value})}/></div>
              <div className="fr2"><div className="fr"><label className="fl">Date</label><input className="fi" type="date" value={f.date||''} onChange={e=>set({...f,date:e.target.value})}/></div><div className="fr"><label className="fl">Heure</label><input className="fi" type="time" value={f.heure||'09:00'} onChange={e=>set({...f,heure:e.target.value})}/></div></div>
              <div className="fr2"><div className="fr"><label className="fl">Contact</label><select className="fi" value={f.contact_id||''} onChange={e=>set({...f,contact_id:e.target.value})}><option value="">—</option>{contacts.map(c=><option key={c.id} value={c.id}>{c.prenom} {c.nom}</option>)}</select></div><div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})}/></div></div>
              <div className="fr"><label className="fl">Description</label><textarea className="fi" rows="2" value={f.desc||f.description||''} onChange={e=>set({...f,desc:e.target.value})}/></div>
            </>
          )}
        </EditModal>
      )}

      {/* Edit Visite */}
      {editItem?.type === 'visit' && (
        <EditModal title="Modifier la visite" onClose={closeEdit} onSave={updateVisite} initial={editItem.data}>
          {(f,set)=>(
            <>
              <div className="fr2"><div className="fr"><label className="fl">Date</label><input className="fi" type="date" value={f.date||''} onChange={e=>set({...f,date:e.target.value})}/></div><div className="fr"><label className="fl">Heure</label><input className="fi" type="time" value={f.heure||'10:00'} onChange={e=>set({...f,heure:e.target.value})}/></div></div>
              <div className="fr2"><div className="fr"><label className="fl">Contact</label><select className="fi" value={f.contact_id||''} onChange={e=>set({...f,contact_id:e.target.value})}><option value="">—</option>{contacts.map(c=><option key={c.id} value={c.id}>{c.prenom} {c.nom}</option>)}</select></div><div className="fr"><label className="fl">Entreprise</label><select className="fi" value={f.entreprise_id||''} onChange={e=>set({...f,entreprise_id:e.target.value})}><option value="">—</option>{ents.map(e=><option key={e.id} value={e.id}>{e.nom}</option>)}</select></div></div>
              <div className="fr2"><div className="fr"><label className="fl">Type</label><select className="fi" value={f.type||'Visite client'} onChange={e=>set({...f,type:e.target.value})}>{['Visite client','Démo','Prospection','Autre'].map(t=><option key={t}>{t}</option>)}</select></div><div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'En attente'} onChange={e=>set({...f,statut:e.target.value})}><option>Confirmée</option><option>En attente</option><option>Annulée</option></select></div></div>
              <div className="fr"><label className="fl">Lieu</label><input className="fi" value={f.lieu||''} onChange={e=>set({...f,lieu:e.target.value})}/></div>
              <div className="fr"><label className="fl">Responsable</label><input className="fi" value={f.resp||''} onChange={e=>set({...f,resp:e.target.value})}/></div>
              <div className="fr"><label className="fl">Notes</label><textarea className="fi" rows="2" value={f.notes||''} onChange={e=>set({...f,notes:e.target.value})}/></div>
            </>
          )}
        </EditModal>
      )}

      {/* Edit Devis statut */}
      {editItem?.type === 'devis-statut' && (
        <EditModal title="Modifier le statut du devis" onClose={closeEdit} onSave={async f=>{
          try {
            await API.updateDevisStatut(f.id, f.statut)
            setDevs(p=>p.map(x=>x.id===f.id?{...x,statut:f.statut}:x))
            closeEdit()
          } catch(err){ alert('Erreur: '+err.message) }
        }} initial={editItem.data}>
          {(f,set)=>(
            <>
              <div style={{fontSize:12,color:'var(--text2)',marginBottom:10}}>{f.ref} — {getEnt(f.entreprise_id).nom}</div>
              <div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'En attente'} onChange={e=>set({...f,statut:e.target.value})}><option>En attente</option><option>Accepté</option><option>Refusé</option><option>Expiré</option></select></div>
            </>
          )}
        </EditModal>
      )}

      {/* Edit Facture statut */}
      {editItem?.type === 'fac' && (
        <EditModal title="Modifier la facture" onClose={closeEdit} onSave={f=>updateFacStatut(f.id, f.statut).then(closeEdit)} initial={editItem.data}>
          {(f,set)=>(
            <>
              <div style={{fontSize:12,color:'var(--text2)',marginBottom:10}}>{f.ref} — {getEnt(f.entreprise_id).nom}</div>
              <div className="fr"><label className="fl">Statut</label><select className="fi" value={f.statut||'En attente'} onChange={e=>set({...f,statut:e.target.value})}><option>En attente</option><option>Payée</option><option>En retard</option><option>Annulée</option></select></div>
            </>
          )}
        </EditModal>
      )}
    </div>
  )
}

// ── Generic form modal ────────────────────────────────────────────────────────
function FormModal({ open, onClose, title, onSave, children }) {
  const [form, setForm] = useState({})
  const handleSave = () => { onSave(form); setForm({}) }
  if (!open) return null
  return (
    <Modal open={open} onClose={onClose} title={title}>
      {children(form, setForm)}
      <div className="mfoot">
        <button className="btn" onClick={onClose}>Annuler</button>
        <button className="btn btn-p" onClick={handleSave}>Enregistrer</button>
      </div>
    </Modal>
  )
}

// ── Edit modal (pre-filled with existing data) ────────────────────────────────
function EditModal({ title, onClose, onSave, initial, children }) {
  const [form, setForm] = useState(initial || {})
  return (
    <Modal open={true} onClose={onClose} title={title}>
      {children(form, setForm)}
      <div className="mfoot">
        <button className="btn" onClick={onClose}>Annuler</button>
        <button className="btn btn-p" onClick={() => onSave(form)}>Enregistrer</button>
      </div>
    </Modal>
  )
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
function Dashboard({ contacts, deals, vis, devs, acts, getEnt, getCont }) {
  const now = new Date()
  const activeDeals = deals.filter(d=>d.etape!=='Gagné'&&d.etape!=='Perdu')
  const thisMonthVis = vis.filter(v=>{ const d=new Date(v.date); return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear() })
  const pendingDevs = devs.filter(d=>d.statut==='En attente')
  const upcomingVis = vis.filter(v=>new Date(v.date)>=now).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4)
  const recentActs = [...acts].slice(-3).reverse()
  const maxV = Math.max(1,...STAGES.map(s=>deals.filter(d=>d.etape===s).reduce((a,d)=>a+d.valeur,0)))

  return (
    <>
      <div className="stats-grid">
        <div className="stat-card"><div className="stat-label">Contacts</div><div className="stat-value">{contacts.length}</div><div className="stat-change up">actifs dans le CRM</div></div>
        <div className="stat-card"><div className="stat-label">Deals actifs</div><div className="stat-value">{activeDeals.length}</div><div className="stat-change up">en cours</div></div>
        <div className="stat-card"><div className="stat-label">Visites ce mois</div><div className="stat-value">{thisMonthVis.length}</div><div className="stat-change up">planifiées</div></div>
        <div className="stat-card"><div className="stat-label">Devis en attente</div><div className="stat-value">{pendingDevs.length}</div><div className="stat-change" style={{color:'var(--text2)'}}>à valider</div></div>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title">Pipeline par étape</div>
          <div className="chart-bars">
            {STAGES.map((s,i)=>{
              const v=deals.filter(d=>d.etape===s).reduce((a,d)=>a+d.valeur,0)
              const h=Math.round((v/maxV)*90)+4
              const colors=['#888780','#378ADD','#534AB7','#BA7517','#1D9E75']
              return <div key={s} className="cbc"><div className="cb" style={{height:h,background:colors[i]}}/><div className="cbl">{s.substring(0,4)}</div></div>
            })}
          </div>
        </div>
        <div className="card">
          <div className="card-title">Prochaines visites</div>
          {upcomingVis.length ? upcomingVis.map(v=>{
            const c=getCont(v.contact_id); const e=getEnt(v.entreprise_id)
            return <div key={v.id} style={{display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:'0.5px solid var(--border1)',fontSize:'12px'}}>
              <div><div style={{fontWeight:500}}>{c.prenom} {c.nom}</div><div style={{color:'var(--text2)',fontSize:'11px'}}>{e.nom} · {v.heure}</div></div>
              <div style={{textAlign:'right'}}><span className={`badge ${D.bcVisitType(v.type)}`}>{v.type}</span><div style={{fontSize:'10px',color:'var(--text2)',marginTop:'2px'}}>{v.date}</div></div>
            </div>
          }) : <div style={{color:'var(--text2)',fontSize:'12px'}}>Aucune visite prévue</div>}
        </div>
      </div>
      <div className="card">
        <div className="card-title">Dernières activités</div>
        <div className="acts">
          {recentActs.map(a=>{ const c=getCont(a.contact_id); return <div key={a.id} className="act"><div className="aico" style={{background:D.ACT_BG[a.type]||'#F1EFE8',color:D.ACT_CO[a.type]||'#5F5E5A'}}>{D.ACT_ICO[a.type]||'·'}</div><div><div style={{fontSize:'12px'}}>{a.titre}{c.nom!=='—'?<> · <b style={{fontWeight:500}}>{c.prenom} {c.nom}</b></>:null}</div><div style={{fontSize:'11px',color:'var(--text2)'}}>{a.date} {a.heure} · {a.resp}</div></div></div> })}
        </div>
      </div>
    </>
  )
}

// ── Contacts ──────────────────────────────────────────────────────────────────
function Contacts({ contacts, setContacts, filter, setFilter, getEnt, setDetail, setPrintJob, openEdit }) {
  const list = filter==='tous' ? contacts : contacts.filter(c=>c.statut===filter)
  const openDetail = c => setDetail(
    <><div style={{marginBottom:'16px'}}><div className="flex aic gap2"><div className={`avatar ${c.avc}`} style={{width:38,height:38,fontSize:13}}>{c.av}</div><div><div style={{fontWeight:500,fontSize:14}}>{c.prenom} {c.nom}</div><div style={{fontSize:11,color:'var(--text2)'}}>{c.poste||''}</div></div></div></div>
    <div className="drow"><span className="dk">Entreprise</span><span className="dv">{getEnt(c.entreprise_id).nom}</span></div>
    <div className="drow"><span className="dk">Email</span><span className="dv" style={{color:'var(--blue-text)'}}>{c.email}</span></div>
    <div className="drow"><span className="dk">Tél.</span><span className="dv">{c.tel}</span></div>
    <div className="drow"><span className="dk">Statut</span><span className="dv"><span className={`badge ${D.bcCont(c.statut)}`}>{c.statut}</span></span></div>
    <div className="drow"><span className="dk">Responsable</span><span className="dv">{c.resp}</span></div>
    <div style={{marginTop:12,display:'flex',gap:7}}><button className="btn btn-p" style={{flex:1,fontSize:11}} onClick={()=>openEdit('contact',c)}>✎ Modifier</button></div></>
  )
  return (
    <div className="card">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <div className="card-title" style={{margin:0}}>{list.length} contact{list.length>1?'s':''}{filter!=='tous'?' · '+filter:''}</div>
        <div style={{display:'flex',gap:8}}>
          <select className="fi" style={{width:'auto',padding:'5px 9px',fontSize:11}} value={filter} onChange={e=>setFilter(e.target.value)}>
            <option value="tous">Tous les statuts</option>
            <option value="Actif">Actif</option><option value="Client">Client</option>
            <option value="Prospect">Prospect</option><option value="Inactif">Inactif</option>
          </select>
          <button className="btn" style={{fontSize:11}} onClick={()=>setPrintJob({type:'contacts',data:{contacts:list,filter}})}>⎙ Imprimer</button>
        </div>
      </div>
      <table><thead><tr><th>Nom</th><th>Entreprise</th><th>Email</th><th>Téléphone</th><th>Statut</th><th>Resp.</th><th></th></tr></thead>
      <tbody>{list.map(c=>(
        <tr key={c.id} onClick={()=>openDetail(c)}>
          <td><div className="flex aic gap2"><div className={`avatar ${c.avc}`}>{c.av}</div>{c.prenom} {c.nom}</div></td>
          <td>{getEnt(c.entreprise_id).nom}</td><td style={{color:'var(--text2)'}}>{c.email}</td><td>{c.tel}</td>
          <td><span className={`badge ${D.bcCont(c.statut)}`}>{c.statut}</span></td><td>{c.resp}</td>
          <td><button className="btn btn-sm" onClick={e=>{e.stopPropagation();API.deleteContact(c.id).then(()=>setContacts(p=>p.filter(x=>x.id!==c.id))).catch(err=>alert('Erreur: '+err.message))}}>×</button></td>
        </tr>
      ))}</tbody></table>
    </div>
  )
}

// ── Pipeline ──────────────────────────────────────────────────────────────────
function Pipeline({ deals, setDeals, getCont, getEnt, setDetail, setPrintJob, openEdit }) {
  const total = deals.reduce((a,d)=>a+d.valeur,0)
  const openDeal = d => setDetail(
    <><div style={{marginBottom:14}}><div style={{fontWeight:500,fontSize:14,marginBottom:4}}>{d.nom}</div><div style={{fontSize:22,fontWeight:500}}>{D.fmtEur(d.valeur)}</div></div>
    <div className="drow"><span className="dk">Étape</span><span className="dv"><span className={`badge ${STAGE_COLORS[d.etape]||'bgr'}`}>{d.etape}</span></span></div>
    <div className="drow"><span className="dk">Contact</span><span className="dv">{getCont(d.contact_id).prenom} {getCont(d.contact_id).nom}</span></div>
    <div className="drow"><span className="dk">Entreprise</span><span className="dv">{getEnt(d.entreprise_id).nom}</span></div>
    <div className="drow"><span className="dk">Probabilité</span><span className="dv">{d.prob}%</span></div>
    <div className="drow"><span className="dk">Responsable</span><span className="dv">{d.resp}</span></div>
    <div className="drow"><span className="dk">Clôture</span><span className="dv">{d.date_cloture||'—'}</span></div>
    <div style={{marginTop:12}}><button className="btn btn-p" style={{width:'100%',fontSize:11}} onClick={()=>openEdit('deal',d)}>✎ Modifier le deal</button></div></>
  )
  return (
    <>
      <div className="pipe">
        {STAGES.map(s=>{
          const sd = deals.filter(d=>d.etape===s)
          return <div key={s} className="pcol">
            <div className="phead"><span>{s}</span><span className={`badge ${STAGE_COLORS[s]}`}>{sd.length}</span></div>
            {sd.map(d=>(
              <div key={d.id} className="dcard" onClick={()=>openDeal(d)}>
                <div style={{fontWeight:500,marginBottom:3}}>{d.nom}</div>
                <div style={{color:'var(--text2)',fontSize:10,marginBottom:4}}>{D.fmtEur(d.valeur)}</div>
                <div className="pbar"><div className="pfill" style={{width:`${d.prob}%`,background:STAGE_BAR[s]}}/></div>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:10,color:'var(--text2)'}}><span>{d.prob}%</span><span>{d.resp}</span></div>
              </div>
            ))}
          </div>
        })}
      </div>
      <div style={{fontSize:11,color:'var(--text2)',textAlign:'right',marginTop:8,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <button className="btn" style={{fontSize:11}} onClick={()=>setPrintJob({type:'pipeline',data:{deals}})}>⎙ Imprimer le pipeline</button>
        <span>Valeur totale pipeline : <strong style={{color:'var(--text1)'}}>{D.fmtEur(total)}</strong></span>
      </div>
    </>
  )
}

// ── Entreprises ───────────────────────────────────────────────────────────────
function Entreprises({ ents, setEnts, contacts, deals, setDetail, openEdit }) {
  const avcs = {1:'ab',2:'ap',3:'at',4:'ac',5:'ak'}
  const openEnt = e => {
    const nb = contacts.filter(c=>c.entreprise_id===e.id)
    setDetail(<>
      <div style={{marginBottom:14}}><div style={{fontWeight:500,fontSize:14}}>{e.nom}</div><div style={{fontSize:11,color:'var(--text2)'}}>{e.secteur} · {e.ville||'—'}</div></div>
      <div className="drow"><span className="dk">Statut</span><span className="dv"><span className={`badge ${e.statut==='Actif'?'bg':'ba'}`}>{e.statut}</span></span></div>
      <div className="drow"><span className="dk">Contacts</span><span className="dv">{nb.length}</span></div>
      <div style={{marginTop:14}}><div style={{fontSize:11,fontWeight:500,marginBottom:8}}>Contacts associés</div>
        {nb.map(c=><div key={c.id} style={{display:'flex',alignItems:'center',gap:7,padding:'5px 0',borderBottom:'0.5px solid var(--border1)'}}><div className={`avatar ${c.avc}`} style={{width:22,height:22,fontSize:9}}>{c.av}</div><div><div style={{fontSize:11,fontWeight:500}}>{c.prenom} {c.nom}</div><div style={{fontSize:10,color:'var(--text2)'}}>{c.poste||''}</div></div></div>)}
      </div>
      <div style={{marginTop:12}}><button className="btn btn-p" style={{width:'100%',fontSize:11}} onClick={()=>openEdit('ent',e)}>✎ Modifier</button></div>
    </>)
  }
  return (
    <div className="card">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <div className="card-title" style={{margin:0}}>{ents.length} entreprises</div>
      </div>
      <table><thead><tr><th>Entreprise</th><th>Secteur</th><th>Ville</th><th>Contacts</th><th>Deals</th><th>Statut</th><th></th></tr></thead>
      <tbody>{ents.map(e=>{
        const nb=contacts.filter(c=>c.entreprise_id===e.id).length
        const nd=deals.filter(d=>d.entreprise_id===e.id&&d.etape!=='Gagné'&&d.etape!=='Perdu').length
        return <tr key={e.id} onClick={()=>openEnt(e)}>
          <td><div className="flex aic gap2"><div className={`avatar ${avcs[e.id]||'ab'}`}>{e.nom.substring(0,2).toUpperCase()}</div>{e.nom}</div></td>
          <td>{e.secteur}</td><td>{e.ville||'—'}</td><td>{nb}</td><td>{nd}</td>
          <td><span className={`badge ${e.statut==='Actif'?'bg':e.statut==='Inactif'?'bgr':'ba'}`}>{e.statut}</span></td>
          <td><button className="btn btn-sm" onClick={ev=>{ev.stopPropagation();API.deleteEntreprise(e.id).then(()=>setEnts(p=>p.filter(x=>x.id!==e.id))).catch(err=>alert('Erreur: '+err.message))}}>×</button></td>
        </tr>
      })}</tbody></table>
    </div>
  )
}

// ── Activités ─────────────────────────────────────────────────────────────────
function Activites({ acts, setActs, getCont, openEdit }) {
  const upcoming = [...acts].filter(a=>a.statut==='Planifiée').sort((a,b)=>a.date.localeCompare(b.date))
  const history  = [...acts].filter(a=>a.statut!=='Planifiée').sort((a,b)=>b.date.localeCompare(a.date))
  const ActList = ({list}) => list.length ? list.map(a=>{
    const c=getCont(a.contact_id)
    return <div key={a.id} className="act">
      <div className="aico" style={{background:D.ACT_BG[a.type]||'#F1EFE8',color:D.ACT_CO[a.type]||'#5F5E5A'}}>{D.ACT_ICO[a.type]||'·'}</div>
      <div style={{flex:1}}><div style={{fontSize:12,fontWeight:500}}>{a.titre}</div><div style={{fontSize:11,color:'var(--text2)'}}>{a.date} {a.heure} · {a.resp}{c.nom!=='—'?' · '+c.prenom+' '+c.nom:''}</div></div>
      <button className="btn btn-sm" style={{fontSize:10}} onClick={()=>openEdit('act',a)}>✎</button>
      <button className="btn btn-sm" onClick={()=>API.deleteActivite(a.id).then(()=>setActs(p=>p.filter(x=>x.id!==a.id))).catch(err=>alert('Erreur: '+err.message))}>×</button>
    </div>
  }) : <div style={{fontSize:12,color:'var(--text2)'}}>Aucune activité</div>
  return (
    <div className="grid-2">
      <div className="card"><div className="card-title">À venir</div><div className="acts"><ActList list={upcoming}/></div></div>
      <div className="card"><div className="card-title">Historique</div><div className="acts"><ActList list={history}/></div></div>
    </div>
  )
}

// ── Planning ──────────────────────────────────────────────────────────────────
function Planning({ vis, setVis, calYear, calMonth, setCalYear, setCalMonth, getCont, getEnt, setDetail, setModal, setPrintJob, openEdit }) {
  const now = new Date()
  const thisMonth = vis.filter(v=>{ const d=new Date(v.date); return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear() })
  const firstDay = new Date(calYear,calMonth,1)
  const lastDay  = new Date(calYear,calMonth+1,0)
  const startDow = (firstDay.getDay()+6)%7
  const label = firstDay.toLocaleDateString('fr-FR',{month:'long',year:'numeric'})
  const todayStr = now.toISOString().split('T')[0]
  const days = ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim']
  const prevMonth = () => { if(calMonth===0){setCalMonth(11);setCalYear(y=>y-1)} else setCalMonth(m=>m-1) }
  const nextMonth = () => { if(calMonth===11){setCalMonth(0);setCalYear(y=>y+1)} else setCalMonth(m=>m+1) }
  const openDay = ds => {
    const dv = vis.filter(v=>v.date===ds)
    if(!dv.length){ setModal('visit'); return }
    const date = new Date(ds).toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'})
    setDetail(<>
      <div style={{fontWeight:500,fontSize:14,marginBottom:12}}>{date.charAt(0).toUpperCase()+date.slice(1)}</div>
      {dv.map(v=>{const c=getCont(v.contact_id);const e=getEnt(v.entreprise_id);return <div key={v.id} style={{padding:10,background:'var(--bg2)',borderRadius:'var(--radius-md)',marginBottom:8}}><div style={{fontWeight:500,fontSize:12}}>{v.heure} · {c.prenom} {c.nom}</div><div style={{fontSize:11,color:'var(--text2)',marginTop:2}}>{e.nom} · {v.lieu||'—'}</div><div style={{marginTop:5}}><span className={`badge ${D.bcVisitType(v.type)}`}>{v.type}</span> <span className={`badge ${D.bcVisit(v.statut)}`}>{v.statut}</span></div>{v.notes?<div style={{fontSize:11,color:'var(--text2)',marginTop:4}}>{v.notes}</div>:null}</div>})}
    </>)
  }
  const cells = []
  for(let i=0;i<startDow;i++) cells.push(<div key={`e${i}`}/>)
  for(let d=1;d<=lastDay.getDate();d++){
    const ds=`${calYear}-${String(calMonth+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`
    const dv=vis.filter(v=>v.date===ds)
    const isToday=ds===todayStr
    cells.push(<div key={d} className={`cal-day${dv.length?' has-visit':''}${isToday?' today':''}`} onClick={()=>openDay(ds)}>
      <div className={`cal-num${isToday?' today-num':''}`}>{d}</div>
      {dv.slice(0,2).map((v,i)=><div key={i} className={`visit-pill ${D.bcVisitType(v.type)}`}>{getCont(v.contact_id).prenom||'?'}</div>)}
      {dv.length>2&&<div style={{fontSize:9,color:'var(--text2)'}}>+{dv.length-2}</div>}
    </div>)
  }
  return (
    <>
      <div className="stats-grid" style={{gridTemplateColumns:'repeat(3,minmax(0,1fr))'}}>
        <div className="stat-card"><div className="stat-label">Visites ce mois</div><div className="stat-value">{thisMonth.length}</div></div>
        <div className="stat-card"><div className="stat-label">Confirmées</div><div className="stat-value">{thisMonth.filter(v=>v.statut==='Confirmée').length}</div></div>
        <div className="stat-card"><div className="stat-label">En attente</div><div className="stat-value">{thisMonth.filter(v=>v.statut==='En attente').length}</div></div>
      </div>
      <div className="card">
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <button className="btn" onClick={prevMonth}>‹</button>
            <span style={{fontSize:13,fontWeight:500}}>{label.charAt(0).toUpperCase()+label.slice(1)}</span>
            <button className="btn" onClick={nextMonth}>›</button>
          </div>
          <div style={{display:'flex',gap:8,fontSize:11,alignItems:'center'}}>
            <span style={{width:10,height:10,background:'var(--blue-bg)',borderRadius:2,border:'1px solid #378ADD',display:'inline-block'}}/>Visite client
            <span style={{width:10,height:10,background:'var(--green-bg)',borderRadius:2,display:'inline-block'}}/>Démo
            <span style={{width:10,height:10,background:'var(--amber-bg)',borderRadius:2,display:'inline-block'}}/>Prospection
          </div>
        </div>
        <div className="cal-grid">{days.map(d=><div key={d} className="cal-head">{d}</div>)}</div>
        <div className="cal-grid" style={{marginTop:4}}>{cells}</div>
      </div>
      <div className="card">
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
          <div className="card-title" style={{margin:0}}>Toutes les visites</div>
          <button className="btn" style={{fontSize:11}} onClick={()=>setPrintJob({type:'planning',data:{visits:vis}})}>⎙ Imprimer le planning</button>
        </div>
        <table><thead><tr><th>Date</th><th>Heure</th><th>Contact</th><th>Entreprise</th><th>Type</th><th>Lieu</th><th>Statut</th><th></th></tr></thead>
        <tbody>{[...vis].sort((a,b)=>a.date.localeCompare(b.date)).map(v=>{
          const c=getCont(v.contact_id);const e=getEnt(v.entreprise_id)
          return <tr key={v.id}><td>{v.date}</td><td>{v.heure}</td><td>{c.prenom} {c.nom}</td><td>{e.nom}</td>
            <td><span className={`badge ${D.bcVisitType(v.type)}`}>{v.type}</span></td>
            <td style={{color:'var(--text2)',fontSize:11}}>{v.lieu||'—'}</td>
            <td><span className={`badge ${D.bcVisit(v.statut)}`}>{v.statut}</span></td>
            <td>
              <button className="btn btn-sm" style={{fontSize:10}} onClick={()=>openEdit('visit',v)}>✎</button>{' '}
              <button className="btn btn-sm" onClick={()=>API.deleteVisite(v.id).then(()=>setVis(p=>p.filter(x=>x.id!==v.id))).catch(err=>alert('Erreur: '+err.message))}>×</button>
            </td>
          </tr>
        })}</tbody></table>
      </div>
    </>
  )
}

// ── Devis ─────────────────────────────────────────────────────────────────────
function Devis({ devs, filter, setFilter, getEnt, setDetail, setPrintJob, openEdit }) {
  const list = filter==='tous' ? devs : devs.filter(d=>d.statut===filter)
  const acc = devs.filter(d=>d.statut==='Accepté').length
  const openDevis = d => setDetail(<>
    <div style={{marginBottom:14}}><div style={{fontSize:11,color:'var(--text2)'}}>{d.ref}</div><div style={{fontWeight:500,fontSize:14}}>{getEnt(d.entreprise_id).nom}</div><span className={`badge ${D.bcDv(d.statut)}`}>{d.statut}</span></div>
    <div className="drow"><span className="dk">Date</span><span className="dv">{d.date}</span></div>
    <div className="drow"><span className="dk">Validité</span><span className="dv">{d.validite}</span></div>
    <div className="drow"><span className="dk">Montant HT</span><span className="dv" style={{fontWeight:500}}>{D.fmtEur(d.ht)}</span></div>
    <div style={{marginTop:12}}><div className="dprev">{d.items.map((it,i)=><div key={i} className="dline"><span>{it.desc} × {it.qty}</span><span>{D.fmtEur(it.pu*it.qty)}</span></div>)}<div className="dline"><span>Total HT</span><span>{D.fmtEur(d.ht)}</span></div></div></div>
    <div style={{marginTop:12,display:'flex',gap:7}}>
      <button className="btn" style={{flex:1,fontSize:11}} onClick={()=>setPrintJob({type:'devis',data:{devis:d,entreprise:getEnt(d.entreprise_id)}})}>⎙ Imprimer</button>
      <button className="btn btn-p" style={{flex:1,fontSize:11}}>→ Facture</button>
    </div>
  </>)
  return (
    <>
      <div className="stats-grid" style={{gridTemplateColumns:'repeat(3,minmax(0,1fr))'}}>
        <div className="stat-card"><div className="stat-label">Total devis</div><div className="stat-value">{devs.length}</div></div>
        <div className="stat-card"><div className="stat-label">En attente (HT)</div><div className="stat-value">{D.fmtEur(devs.filter(d=>d.statut==='En attente').reduce((a,d)=>a+d.ht,0))}</div></div>
        <div className="stat-card"><div className="stat-label">Taux d'acceptation</div><div className="stat-value">{devs.length?Math.round(acc/devs.length*100):0}%</div></div>
      </div>
      <div className="card">
        <div className="tab-bar">{['tous','En attente','Accepté','Refusé'].map(t=>(
          <div key={t} className={`tab${filter===t?' active':''}`} onClick={()=>setFilter(t)}>{t==='tous'?'Tous':t==='En attente'?'En attente':t+'s'}</div>
        ))}</div>
        <table><thead><tr><th>Référence</th><th>Client</th><th>Date</th><th>Validité</th><th>Montant HT</th><th>Statut</th><th></th></tr></thead>
        <tbody>{list.map(d=>(
          <tr key={d.id} onClick={()=>openDevis(d)}>
            <td style={{color:'var(--text2)',fontWeight:500}}>{d.ref}</td><td>{getEnt(d.entreprise_id).nom}</td>
            <td>{d.date}</td><td>{d.validite}</td><td style={{fontWeight:500}}>{D.fmtEur(d.ht)}</td>
            <td><span className={`badge ${D.bcDv(d.statut)}`}>{d.statut}</span></td>
            <td style={{whiteSpace:'nowrap'}}>
              <button className="btn btn-sm" style={{fontSize:10}} onClick={e=>{e.stopPropagation();openEdit('devis-statut',d)}} title="Modifier statut">✎</button>{' '}
              <button className="btn btn-sm" onClick={e=>{e.stopPropagation();setPrintJob({type:'devis',data:{devis:d,entreprise:getEnt(d.entreprise_id)}})}} title="Imprimer">⎙</button>{' '}
              <button className="btn btn-sm" onClick={e=>e.stopPropagation()}>→ Facture</button>
            </td>
          </tr>
        ))}</tbody></table>
      </div>
    </>
  )
}

// ── Factures ──────────────────────────────────────────────────────────────────
function Factures({ facs, setFacs, filter, setFilter, getEnt, setDetail, devs, setPrintJob, openEdit }) {
  const list = filter==='tous' ? facs : facs.filter(f=>f.statut===filter)
  const sum  = s => facs.filter(f=>f.statut===s).reduce((a,f)=>a+f.ht*(1+f.tva/100),0)
  const openFac = f => {
    const ttc=f.ht*(1+f.tva/100)
    const dv = devs?.find(x=>x.id===f.devis_id)
    setDetail(<>
      <div style={{marginBottom:14}}><div style={{fontSize:11,color:'var(--text2)'}}>{f.ref}</div><div style={{fontWeight:500,fontSize:14}}>{getEnt(f.entreprise_id).nom}</div><span className={`badge ${D.bcFac(f.statut)}`}>{f.statut}</span></div>
      <div className="drow"><span className="dk">Émission</span><span className="dv">{f.emission}</span></div>
      <div className="drow"><span className="dk">Échéance</span><span className="dv">{f.echeance}</span></div>
      <div style={{marginTop:12}}><div className="dprev"><div className="dline"><span>Montant HT</span><span>{D.fmtEur(f.ht)}</span></div><div className="dline"><span>TVA {f.tva}%</span><span>{D.fmtEur(f.ht*f.tva/100)}</span></div><div className="dline"><span>Total TTC</span><span>{D.fmtEur(ttc)}</span></div></div></div>
      <div style={{marginTop:12,display:'flex',gap:7,flexWrap:'wrap'}}>
        {f.statut!=='Payée'&&<button className="btn btn-p" style={{flex:1,fontSize:11}} onClick={()=>API.payerFacture(f.id).then(()=>setFacs(p=>p.map(x=>x.id===f.id?{...x,statut:'Payée'}:x))).catch(err=>alert('Erreur: '+err.message))}>Marquer payée</button>}
        {f.statut!=='Payée'&&<button className="btn" style={{flex:1,fontSize:11}}>Relancer</button>}
        <button className="btn" style={{flex:'1 1 100%',fontSize:11}} onClick={()=>setPrintJob({type:'facture',data:{facture:f,entreprise:getEnt(f.entreprise_id),devisRef:dv?.ref}})}>⎙ Imprimer la facture</button>
      </div>
    </>)
  }
  return (
    <>
      <div className="stats-grid">
        <div className="stat-card"><div className="stat-label">Total émises</div><div className="stat-value">{facs.length}</div></div>
        <div className="stat-card"><div className="stat-label">Payées</div><div className="stat-value">{D.fmtEur(sum('Payée'))}</div></div>
        <div className="stat-card"><div className="stat-label">En attente</div><div className="stat-value">{D.fmtEur(sum('En attente'))}</div></div>
        <div className="stat-card"><div className="stat-label">En retard</div><div className="stat-value">{D.fmtEur(sum('En retard'))}</div></div>
      </div>
      <div className="card">
        <div className="tab-bar">{['tous','Payée','En attente','En retard'].map(t=>(
          <div key={t} className={`tab${filter===t?' active':''}`} onClick={()=>setFilter(t)}>{t==='tous'?'Toutes':t==='Payée'?'Payées':t}</div>
        ))}</div>
        <table><thead><tr><th>Référence</th><th>Client</th><th>Émission</th><th>Échéance</th><th>Montant TTC</th><th>Statut</th><th></th></tr></thead>
        <tbody>{list.map(f=>{
          const ttc=f.ht*(1+f.tva/100)
          return <tr key={f.id} onClick={()=>openFac(f)}>
            <td style={{color:'var(--text2)',fontWeight:500}}>{f.ref}</td><td>{getEnt(f.entreprise_id).nom}</td>
            <td>{f.emission}</td><td>{f.echeance}</td><td style={{fontWeight:500}}>{D.fmtEur(ttc)}</td>
            <td><span className={`badge ${D.bcFac(f.statut)}`}>{f.statut}</span></td>
            <td style={{whiteSpace:'nowrap'}}>
              <button className="btn btn-sm" style={{fontSize:10}} onClick={e=>{e.stopPropagation();openEdit('fac',f)}} title="Modifier">✎</button>{' '}
              {f.statut!=='Payée'&&<><button className="btn btn-sm" onClick={e=>e.stopPropagation()}>Relancer</button>{' '}</>}
              <button className="btn btn-sm" onClick={e=>{e.stopPropagation();const dv=devs?.find(x=>x.id===f.devis_id);setPrintJob({type:'facture',data:{facture:f,entreprise:getEnt(f.entreprise_id),devisRef:dv?.ref}})}} title="Imprimer">⎙</button>
            </td>
          </tr>
        })}</tbody></table>
      </div>
    </>
  )
}
