// ─── Configuration ───────────────────────────────────────────────────────────
// Priorité : variable VITE_API_URL > /api (même domaine, pour prod mutualisé)
export const API_BASE = import.meta.env.VITE_API_URL || '/api'

// ─── Requête avec timeout et messages d'erreur clairs ────────────────────────
async function req(method, path, body) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 10000)

  try {
    const opts = {
      method,
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
    }
    if (body) opts.body = JSON.stringify(body)

    const res = await fetch(`${API_BASE}${path}`, opts)
    clearTimeout(timer)

    if (!res.ok) {
      let msg = `HTTP ${res.status}`
      try { const j = await res.json(); msg = j.error || msg } catch {}
      throw new Error(msg)
    }
    return res.json()
  } catch (err) {
    clearTimeout(timer)
    if (err.name === 'AbortError')
      throw new Error('Délai dépassé — le serveur ne répond pas (timeout 10s)')
    if (err.message.toLowerCase().includes('failed to fetch') || err.message.toLowerCase().includes('networkerror'))
      throw new Error(`Impossible de joindre l'API.\n\nURL : ${API_BASE}\n\nCauses possibles :\n• Le backend n'est pas démarré\n• VITE_API_URL est incorrect dans .env\n• Problème CORS ou pare-feu`)
    throw err
  }
}

// ─── Health check ─────────────────────────────────────────────────────────────
export const checkHealth = () => req('GET', '/health')

// ─── Dashboard ────────────────────────────────────────────────────────────────
export const getDashboard = () => req('GET', '/dashboard')

// ─── Entreprises ──────────────────────────────────────────────────────────────
export const getEntreprises   = ()       => req('GET',    '/entreprises')
export const createEntreprise = (data)   => req('POST',   '/entreprises', data)
export const updateEntreprise = (id, d)  => req('PUT',    `/entreprises/${id}`, d)
export const deleteEntreprise = (id)     => req('DELETE', `/entreprises/${id}`)

// ─── Contacts ─────────────────────────────────────────────────────────────────
export const getContacts  = (statut) => req('GET', `/contacts${statut && statut !== 'tous' ? `?statut=${statut}` : ''}`)
export const createContact= (data)   => req('POST',   '/contacts', data)
export const updateContact= (id, d)  => req('PUT',    `/contacts/${id}`, d)
export const deleteContact= (id)     => req('DELETE', `/contacts/${id}`)

// ─── Deals ────────────────────────────────────────────────────────────────────
export const getDeals  = ()      => req('GET',    '/deals')
export const createDeal= (data)  => req('POST',   '/deals', data)
export const updateDeal= (id, d) => req('PUT',    `/deals/${id}`, d)
export const deleteDeal= (id)    => req('DELETE', `/deals/${id}`)

// ─── Activités ────────────────────────────────────────────────────────────────
export const getActivites   = ()      => req('GET',    '/activites')
export const createActivite = (data)  => req('POST',   '/activites', data)
export const updateActivite = (id, d) => req('PUT',    `/activites/${id}`, d)
export const deleteActivite = (id)    => req('DELETE', `/activites/${id}`)

// ─── Visites ──────────────────────────────────────────────────────────────────
export const getVisites   = ()      => req('GET',    '/visites')
export const createVisite = (data)  => req('POST',   '/visites', data)
export const updateVisite = (id, d) => req('PUT',    `/visites/${id}`, d)
export const deleteVisite = (id)    => req('DELETE', `/visites/${id}`)

// ─── Devis ────────────────────────────────────────────────────────────────────
export const getDevis         = (statut) => req('GET', `/devis${statut && statut !== 'tous' ? `?statut=${statut}` : ''}`)
export const getDevisById     = (id)     => req('GET',    `/devis/${id}`)
export const createDevis      = (data)   => req('POST',   '/devis', data)
export const updateDevisStatut= (id, s)  => req('PUT',    `/devis/${id}/statut`, { statut: s })
export const convertDevis     = (id, d)  => req('POST',   `/devis/${id}/convertir`, d)
export const deleteDevis      = (id)     => req('DELETE', `/devis/${id}`)

// ─── Factures ─────────────────────────────────────────────────────────────────
export const getFactures  = (statut) => req('GET', `/factures${statut && statut !== 'tous' ? `?statut=${statut}` : ''}`)
export const createFacture= (data)   => req('POST',   '/factures', data)
export const updateFacture= (id, d)  => req('PUT',    `/factures/${id}`, d)
export const payerFacture = (id)     => req('PUT',    `/factures/${id}/payer`)
export const deleteFacture= (id)     => req('DELETE', `/factures/${id}`)
