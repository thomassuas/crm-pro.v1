export default function DetailPanel({ open, onClose, children }) {
  return (
    <div className={`dp${open ? ' open' : ''}`}>
      <button className="cbtn" style={{float:'right',background:'none',border:'none',cursor:'pointer',color:'var(--text2)',fontSize:'17px'}} onClick={onClose}>×</button>
      <div style={{marginTop:'8px'}}>{children}</div>
    </div>
  )
}
