export let contacts = [
  { id:1, prenom:'Marie',  nom:'Dupont',  entreprise_id:1, email:'m.dupont@renault.fr',  tel:'+33 6 12 34 56 78', poste:'Dir. Marketing',   statut:'Actif',    resp:'Thomas', av:'MD', avc:'ab' },
  { id:2, prenom:'Jean',   nom:'Martin',  entreprise_id:2, email:'j.martin@lvmh.com',    tel:'+33 6 98 76 54 32', poste:'DSI',              statut:'Actif',    resp:'Lucie',  av:'JM', avc:'ap' },
  { id:3, prenom:'Sophie', nom:'Leclerc', entreprise_id:3, email:'s.leclerc@airbus.com', tel:'+33 6 55 44 33 22', poste:'Resp. Achats',     statut:'Client',   resp:'Thomas', av:'SL', avc:'at' },
  { id:4, prenom:'Pierre', nom:'Bernard', entreprise_id:4, email:'p.bernard@orange.fr',  tel:'+33 6 11 22 33 44', poste:'Chef Projet',      statut:'Prospect', resp:'Marc',   av:'PB', avc:'ac' },
  { id:5, prenom:'Claire', nom:'Moreau',  entreprise_id:1, email:'c.moreau@renault.fr',  tel:'+33 6 77 88 99 00', poste:'Acheteuse',        statut:'Client',   resp:'Thomas', av:'CM', avc:'ak' },
  { id:6, prenom:'Lucas',  nom:'Simon',   entreprise_id:5, email:'l.simon@total.fr',     tel:'+33 6 44 55 66 77', poste:'Manager IT',       statut:'Prospect', resp:'Emma',   av:'LS', avc:'ab' },
  { id:7, prenom:'Emma',   nom:'Petit',   entreprise_id:2, email:'e.petit@lvmh.com',     tel:'+33 6 33 22 11 00', poste:'Chef de compte',   statut:'Actif',    resp:'Lucie',  av:'EP', avc:'ap' },
  { id:8, prenom:'Romain', nom:'Leroy',   entreprise_id:3, email:'r.leroy@airbus.com',   tel:'+33 6 66 77 88 99', poste:'Ingénieur',        statut:'Inactif',  resp:'Marc',   av:'RL', avc:'at' },
]

export let entreprises = [
  { id:1, nom:'Renault',       secteur:'Automobile',   statut:'Actif',    ville:'Boulogne-Billancourt' },
  { id:2, nom:'LVMH',          secteur:'Luxe',         statut:'Actif',    ville:'Paris' },
  { id:3, nom:'Airbus',        secteur:'Aéronautique', statut:'Actif',    ville:'Toulouse' },
  { id:4, nom:'Orange',        secteur:'Télécoms',     statut:'Prospect', ville:'Paris' },
  { id:5, nom:'TotalEnergies', secteur:'Énergie',      statut:'Actif',    ville:'Courbevoie' },
]

export let deals = [
  { id:1, nom:'Achat SaaS Renault',       valeur:45000,  prob:80,  etape:'Négociation', contact_id:1, entreprise_id:1, resp:'Thomas', date_cloture:'2026-04-30' },
  { id:2, nom:'Renouvellement LVMH',      valeur:120000, prob:60,  etape:'Proposition', contact_id:2, entreprise_id:2, resp:'Lucie',  date_cloture:'2026-05-15' },
  { id:3, nom:'Contrat Airbus',           valeur:80000,  prob:100, etape:'Gagné',       contact_id:3, entreprise_id:3, resp:'Thomas', date_cloture:'2026-03-31' },
  { id:4, nom:'Upgrade Orange',           valeur:22000,  prob:40,  etape:'Qualifié',    contact_id:4, entreprise_id:4, resp:'Marc',   date_cloture:'2026-06-01' },
  { id:5, nom:'Expansion TotalEnergies',  valeur:35000,  prob:20,  etape:'Prospection', contact_id:6, entreprise_id:5, resp:'Emma',   date_cloture:'2026-07-01' },
]

export let activites = [
  { id:1, type:'Réunion', titre:'Réunion Sophie Leclerc', statut:'Planifiée', date:'2026-04-09', heure:'14:00', contact_id:3, resp:'Thomas', desc:'Présentation nouvelle offre' },
  { id:2, type:'Email',   titre:'Suivi Jean Martin',      statut:'Planifiée', date:'2026-04-10', heure:'09:00', contact_id:2, resp:'Lucie',  desc:'' },
  { id:3, type:'Appel',   titre:'Démo Pierre Bernard',    statut:'Planifiée', date:'2026-04-10', heure:'11:00', contact_id:4, resp:'Marc',   desc:'' },
  { id:4, type:'Email',   titre:'Envoi proposition',      statut:'Terminée',  date:'2026-04-07', heure:'10:00', contact_id:1, resp:'Thomas', desc:'' },
  { id:5, type:'Appel',   titre:'Qualif. Lucas Simon',    statut:'Terminée',  date:'2026-04-06', heure:'15:00', contact_id:6, resp:'Emma',   desc:'Durée: 25 min' },
]

export let visits = [
  { id:1, date:'2026-04-09', heure:'14:00', contact_id:3, entreprise_id:3, type:'Visite client', lieu:'Toulouse — Airbus HQ',       statut:'Confirmée',  resp:'Thomas', notes:'Présentation Q2' },
  { id:2, date:'2026-04-11', heure:'10:00', contact_id:1, entreprise_id:1, type:'Démo',          lieu:'Boulogne — Renault HQ',      statut:'Confirmée',  resp:'Thomas', notes:'' },
  { id:3, date:'2026-04-15', heure:'09:30', contact_id:2, entreprise_id:2, type:'Visite client', lieu:'Paris — LVMH',               statut:'En attente', resp:'Lucie',  notes:'Renouvellement contrat' },
  { id:4, date:'2026-04-17', heure:'14:00', contact_id:4, entreprise_id:4, type:'Prospection',   lieu:'Paris — Orange',             statut:'En attente', resp:'Marc',   notes:'' },
  { id:5, date:'2026-04-22', heure:'11:00', contact_id:6, entreprise_id:5, type:'Démo',          lieu:'Courbevoie — TotalEnergies', statut:'Confirmée',  resp:'Emma',   notes:'' },
  { id:6, date:'2026-04-28', heure:'15:00', contact_id:5, entreprise_id:1, type:'Visite client', lieu:'Boulogne — Renault',         statut:'Confirmée',  resp:'Thomas', notes:'' },
]

export let devisData = [
  { id:1, ref:'DEV-024', entreprise_id:1, date:'2026-03-25', validite:'2026-04-25', ht:45000,  statut:'En attente', items:[{desc:'Licence SaaS',qty:1,pu:40000},{desc:'Formation',qty:2,pu:2500}] },
  { id:2, ref:'DEV-023', entreprise_id:2, date:'2026-03-18', validite:'2026-04-18', ht:120000, statut:'Accepté',    items:[{desc:'Plateforme Enterprise',qty:1,pu:100000},{desc:'Support Premium',qty:1,pu:20000}] },
  { id:3, ref:'DEV-022', entreprise_id:4, date:'2026-03-10', validite:'2026-04-10', ht:22000,  statut:'En attente', items:[{desc:'Module Télécoms',qty:2,pu:9000},{desc:'Intégration API',qty:1,pu:4000}] },
  { id:4, ref:'DEV-021', entreprise_id:3, date:'2026-03-01', validite:'2026-04-01', ht:80000,  statut:'Accepté',    items:[{desc:'Suite Aéro',qty:1,pu:75000},{desc:'Maintenance',qty:1,pu:5000}] },
  { id:5, ref:'DEV-020', entreprise_id:5, date:'2026-02-20', validite:'2026-03-20', ht:35000,  statut:'Refusé',     items:[{desc:'Module Énergie',qty:1,pu:35000}] },
]

export let facturesData = [
  { id:1, ref:'FAC-031', entreprise_id:3, devis_id:4, emission:'2026-03-08', echeance:'2026-04-15', ht:80000,  tva:20, statut:'Payée' },
  { id:2, ref:'FAC-030', entreprise_id:2, devis_id:2, emission:'2026-03-18', echeance:'2026-04-01', ht:120000, tva:20, statut:'En retard' },
  { id:3, ref:'FAC-029', entreprise_id:1, devis_id:1, emission:'2026-03-25', echeance:'2026-04-20', ht:22500,  tva:20, statut:'En attente' },
]

export const getEnt  = (id) => entreprises.find(e => e.id === id) || { nom: '—' }
export const getCont = (id) => contacts.find(c => c.id === id)    || { prenom: '', nom: '—' }
export const fmtEur  = (n)  => '€' + Math.round(n).toLocaleString('fr-FR')

export const bcCont     = s => s==='Actif'?'bg':s==='Client'?'bb':s==='Inactif'?'bgr':'ba'
export const bcFac      = s => s==='Payée'?'bg':s==='En retard'?'br':'ba'
export const bcDv       = s => s==='Accepté'?'bg':s==='Refusé'?'br':'ba'
export const bcVisit    = s => s==='Confirmée'?'bg':s==='Annulée'?'br':'ba'
export const bcVisitType= t => t==='Visite client'?'vp-blue':t==='Démo'?'vp-green':t==='Prospection'?'vp-amber':'vp-purple'

export const ACT_ICO = { Email:'✉', Appel:'☎', Réunion:'⊙', Tâche:'✓', Note:'✎' }
export const ACT_BG  = { Email:'#E6F1FB', Appel:'#EEEDFE', Réunion:'#FAEEDA', Tâche:'#EAF3DE', Note:'#F1EFE8' }
export const ACT_CO  = { Email:'#185FA5', Appel:'#534AB7', Réunion:'#854F0B', Tâche:'#3B6D11', Note:'#5F5E5A' }
