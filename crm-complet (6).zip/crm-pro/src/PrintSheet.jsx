import { useEffect } from 'react'
import { createPortal } from 'react-dom'

const fmtEur  = n => '€' + Math.round(n).toLocaleString('fr-FR')
const fmtDate = s => { try { return new Date(s).toLocaleDateString('fr-FR') } catch { return s||'—' } }
const todayFr = () => new Date().toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'})

const statusCls = s => {
  if (['Payée','Accepté','Confirmée','Actif','Client','Gagné'].includes(s)) return 'psg'
  if (['En attente','Planifiée','Proposition','Qualifié'].includes(s))      return 'psa'
  if (['En retard','Refusé','Annulée','Inactif','Perdu'].includes(s))       return 'psr'
  if (['Prospect','Prospection','Négociation'].includes(s))                  return 'psb'
  return 'psgr'
}

const CSS = `
.ps-ov{position:fixed;inset:0;z-index:99999;background:#fff;overflow-y:auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#1a1a1a;font-size:10pt;line-height:1.5}
.ps-bar{position:sticky;top:0;z-index:10;background:#1a1a1a;color:#fff;padding:10px 24px;display:flex;align-items:center;gap:12px}
.ps-bar-t{flex:1;font-size:13px;font-weight:500}
.ps-bb{padding:6px 14px;border-radius:7px;font-size:12px;cursor:pointer;border:1px solid rgba(255,255,255,.3);background:transparent;color:#fff}
.ps-bb:hover{background:rgba(255,255,255,.1)}
.ps-bbp{background:#fff;color:#1a1a1a;border-color:#fff;font-weight:600}
.ps-bbp:hover{opacity:.88}
.ps-doc{width:210mm;margin:0 auto;padding:16mm 18mm 20mm}
.ps-hd{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:10mm;border-bottom:1.5pt solid #1a1a1a;margin-bottom:8mm}
.ps-logo{font-size:18pt;font-weight:700;letter-spacing:-.5px}
.ps-logo span{font-weight:300}
.ps-dt{font-size:22pt;font-weight:700;text-align:right;line-height:1.1}
.ps-dr{font-size:9pt;color:#777;text-align:right;margin-top:1.5mm}
.ps-pts{display:grid;grid-template-columns:1fr 1fr;gap:8mm;margin-bottom:8mm}
.ps-pl{font-size:7.5pt;text-transform:uppercase;letter-spacing:1px;color:#999;margin-bottom:2mm}
.ps-pn{font-size:12pt;font-weight:600;margin-bottom:1mm}
.ps-pi{font-size:9pt;color:#555;line-height:1.7}
.ps-mt{display:flex;gap:5mm;margin-bottom:8mm}
.ps-mb{flex:1;padding:3mm 4mm;border:.5pt solid #ddd;border-radius:4pt}
.ps-ml{font-size:7pt;text-transform:uppercase;letter-spacing:.7px;color:#999;margin-bottom:1mm}
.ps-mv{font-size:10pt;font-weight:500}
.ps-tbl{width:100%;border-collapse:collapse;margin-bottom:6mm;font-size:9.5pt}
.ps-tbl thead tr{background:#1a1a1a;color:#fff}
.ps-tbl thead th{padding:2.5mm 3mm;text-align:left;font-weight:500;font-size:8.5pt}
.ps-tbl thead th.r{text-align:right}
.ps-tbl thead th.c{text-align:center}
.ps-tbl tbody tr:nth-child(even){background:#f8f8f6}
.ps-tbl tbody td{padding:2mm 3mm;border-bottom:.5pt solid #e8e8e8}
.ps-tbl tbody td.r{text-align:right;font-weight:500}
.ps-tbl tbody td.c{text-align:center}
.ps-tots{margin-left:auto;width:70mm}
.ps-tr{display:flex;justify-content:space-between;padding:1.5mm 0;font-size:9.5pt;border-bottom:.5pt solid #eee}
.ps-tr.ttc{font-size:12pt;font-weight:700;border-top:1.5pt solid #1a1a1a;border-bottom:none;padding-top:3mm;margin-top:1mm}
.ps-note{margin-top:10mm;padding:4mm;border:.5pt solid #ddd;border-radius:4pt;font-size:9pt;color:#555;line-height:1.6}
.ps-ft{margin-top:10mm;padding-top:5mm;border-top:.5pt solid #ddd;font-size:8pt;color:#999;display:flex;justify-content:space-between}
.ps-st{display:inline-block;padding:1mm 3mm;border-radius:20pt;font-size:8pt;font-weight:600}
.psg {background:#EAF3DE;color:#3B6D11;border:.5pt solid #3B6D11}
.psa {background:#FAEEDA;color:#854F0B;border:.5pt solid #854F0B}
.psr {background:#FCEBEB;color:#A32D2D;border:.5pt solid #A32D2D}
.psb {background:#E6F1FB;color:#185FA5;border:.5pt solid #185FA5}
.psgr{background:#F1EFE8;color:#5F5E5A;border:.5pt solid #5F5E5A}
.ps-stitle{font-size:15pt;font-weight:700;margin-bottom:4mm;padding-bottom:3mm;border-bottom:1.5pt solid #1a1a1a}
@media print{
  .ps-bar{display:none!important}
  .ps-ov{position:static!important}
  .ps-doc{width:100%;padding:0}
}
`

const Logo = () => <div className="ps-logo">CRM<span>Pro</span></div>
const OurInfo = () => (
  <div className="ps-pi">CRM Pro SAS<br/>12 rue de la Paix — 75001 Paris<br/>contact@crmpro.fr · +33 1 23 45 67 89<br/>SIRET 123 456 789 00012</div>
)

function DevisDoc({ devis, entreprise }) {
  const tva = devis.ht * 0.20, ttc = devis.ht + tva
  return (
    <div className="ps-doc">
      <div className="ps-hd">
        <div><Logo /><div style={{marginTop:'3mm',fontSize:'9pt',color:'#777'}}>Émis le {todayFr()}</div></div>
        <div><div className="ps-dt">DEVIS</div><div className="ps-dr">{devis.ref}</div><div style={{marginTop:'2mm'}}><span className={`ps-st ${statusCls(devis.statut)}`}>{devis.statut}</span></div></div>
      </div>
      <div className="ps-pts">
        <div><div className="ps-pl">Émetteur</div><div className="ps-pn">CRM Pro SAS</div><OurInfo /></div>
        <div><div className="ps-pl">Destinataire</div><div className="ps-pn">{entreprise.nom}</div><div className="ps-pi">{entreprise.secteur}<br/>{entreprise.ville||'—'}</div></div>
      </div>
      <div className="ps-mt">
        <div className="ps-mb"><div className="ps-ml">Date d'émission</div><div className="ps-mv">{fmtDate(devis.date)}</div></div>
        <div className="ps-mb"><div className="ps-ml">Valide jusqu'au</div><div className="ps-mv">{fmtDate(devis.validite)}</div></div>
        <div className="ps-mb"><div className="ps-ml">Référence</div><div className="ps-mv">{devis.ref}</div></div>
      </div>
      <table className="ps-tbl">
        <thead><tr><th style={{width:'48%'}}>Description</th><th style={{width:'12%'}}>Qté</th><th className="r" style={{width:'20%'}}>Prix unit. HT</th><th className="r" style={{width:'20%'}}>Total HT</th></tr></thead>
        <tbody>{(devis.items||[]).map((it,i)=><tr key={i}><td>{it.desc}</td><td>{it.qty}</td><td className="r">{fmtEur(it.pu)}</td><td className="r">{fmtEur(it.pu*it.qty)}</td></tr>)}</tbody>
      </table>
      <div className="ps-tots">
        <div className="ps-tr"><span>Sous-total HT</span><span>{fmtEur(devis.ht)}</span></div>
        <div className="ps-tr"><span>TVA 20 %</span><span>{fmtEur(tva)}</span></div>
        <div className="ps-tr ttc"><span>Total TTC</span><span>{fmtEur(ttc)}</span></div>
      </div>
      <div className="ps-note"><strong>Conditions :</strong> Devis valable 30 jours. Paiement à 30 jours après acceptation. Ce document vaut bon de commande dès signature.</div>
      <div className="ps-ft"><span>CRM Pro SAS — SIRET 123 456 789 00012</span><span>{devis.ref} — {todayFr()}</span></div>
    </div>
  )
}

function FactureDoc({ facture, entreprise, devisRef }) {
  const tva = facture.ht*(facture.tva/100), ttc = facture.ht+tva
  return (
    <div className="ps-doc">
      <div className="ps-hd">
        <div><Logo /><div style={{marginTop:'3mm',fontSize:'9pt',color:'#777'}}>Émis le {fmtDate(facture.emission)}</div></div>
        <div><div className="ps-dt">FACTURE</div><div className="ps-dr">{facture.ref}</div>{devisRef&&<div style={{fontSize:'8.5pt',color:'#999',marginTop:'1mm'}}>Devis : {devisRef}</div>}<div style={{marginTop:'2mm'}}><span className={`ps-st ${statusCls(facture.statut)}`}>{facture.statut}</span></div></div>
      </div>
      <div className="ps-pts">
        <div><div className="ps-pl">Émetteur</div><div className="ps-pn">CRM Pro SAS</div><OurInfo /></div>
        <div><div className="ps-pl">Facturé à</div><div className="ps-pn">{entreprise.nom}</div><div className="ps-pi">{entreprise.secteur}<br/>{entreprise.ville||'—'}</div></div>
      </div>
      <div className="ps-mt">
        <div className="ps-mb"><div className="ps-ml">Date d'émission</div><div className="ps-mv">{fmtDate(facture.emission)}</div></div>
        <div className="ps-mb"><div className="ps-ml">Échéance</div><div className="ps-mv" style={{color:facture.statut==='En retard'?'#A32D2D':undefined}}>{fmtDate(facture.echeance)}</div></div>
        <div className="ps-mb"><div className="ps-ml">Référence</div><div className="ps-mv">{facture.ref}</div></div>
        <div className="ps-mb"><div className="ps-ml">TVA</div><div className="ps-mv">{facture.tva} %</div></div>
      </div>
      <table className="ps-tbl">
        <thead><tr><th style={{width:'60%'}}>Désignation</th><th className="r" style={{width:'20%'}}>Montant HT</th><th className="r" style={{width:'20%'}}>Total HT</th></tr></thead>
        <tbody><tr><td>Prestations de services — {entreprise.nom}</td><td className="r">{fmtEur(facture.ht)}</td><td className="r">{fmtEur(facture.ht)}</td></tr></tbody>
      </table>
      <div className="ps-tots">
        <div className="ps-tr"><span>Montant HT</span><span>{fmtEur(facture.ht)}</span></div>
        <div className="ps-tr"><span>TVA {facture.tva} %</span><span>{fmtEur(tva)}</span></div>
        <div className="ps-tr ttc"><span>Net à payer TTC</span><span>{fmtEur(ttc)}</span></div>
      </div>
      <div className="ps-note"><strong>Paiement :</strong> Virement bancaire — IBAN FR76 3000 1007 9412 3456 7890 185 — BIC BNPAFRPP.<br/>Pénalités de retard : 3× taux légal + indemnité forfaitaire 40 €.</div>
      <div className="ps-ft"><span>CRM Pro SAS — SIRET 123 456 789 00012 — TVA FR 12 345 678 900</span><span>{facture.ref} — {todayFr()}</span></div>
    </div>
  )
}

function ContactsDoc({ contacts, getEnt, filter }) {
  return (
    <div className="ps-doc">
      <div className="ps-hd">
        <Logo />
        <div><div className="ps-dt" style={{fontSize:'16pt'}}>LISTE DES CONTACTS</div><div className="ps-dr">{todayFr()}</div>{filter!=='tous'&&<div style={{marginTop:'2mm'}}><span className={`ps-st ${statusCls(filter)}`}>{filter}</span></div>}</div>
      </div>
      <table className="ps-tbl">
        <thead><tr><th>Nom</th><th>Entreprise</th><th>Email</th><th>Téléphone</th><th>Poste</th><th>Statut</th><th>Resp.</th></tr></thead>
        <tbody>{contacts.map(c=><tr key={c.id}><td style={{fontWeight:500}}>{c.prenom} {c.nom}</td><td>{getEnt(c.entreprise_id).nom}</td><td style={{fontSize:'8pt'}}>{c.email}</td><td style={{fontSize:'8.5pt'}}>{c.tel}</td><td style={{fontSize:'8pt',color:'#666'}}>{c.poste}</td><td><span className={`ps-st ${statusCls(c.statut)}`}>{c.statut}</span></td><td>{c.resp}</td></tr>)}</tbody>
      </table>
      <div className="ps-ft"><span>{contacts.length} contact{contacts.length>1?'s':''}</span><span>CRM Pro — {todayFr()}</span></div>
    </div>
  )
}

function PlanningDoc({ visits, getCont, getEnt }) {
  const sorted = [...visits].sort((a,b)=>a.date.localeCompare(b.date))
  return (
    <div className="ps-doc">
      <div className="ps-hd"><Logo /><div><div className="ps-dt" style={{fontSize:'15pt'}}>PLANNING DES VISITES</div><div className="ps-dr">{todayFr()}</div></div></div>
      <table className="ps-tbl">
        <thead><tr><th>Date</th><th>Heure</th><th>Contact</th><th>Entreprise</th><th>Type</th><th>Lieu</th><th>Resp.</th><th>Statut</th></tr></thead>
        <tbody>{sorted.map(v=>{const c=getCont(v.contact_id);const e=getEnt(v.entreprise_id);return<tr key={v.id}><td style={{fontWeight:500,whiteSpace:'nowrap'}}>{fmtDate(v.date)}</td><td>{v.heure}</td><td>{c.prenom} {c.nom}</td><td>{e.nom}</td><td style={{fontSize:'8.5pt'}}>{v.type}</td><td style={{fontSize:'8pt',color:'#666'}}>{v.lieu||'—'}</td><td>{v.resp}</td><td><span className={`ps-st ${statusCls(v.statut)}`}>{v.statut}</span></td></tr>})}</tbody>
      </table>
      {sorted.some(v=>v.notes)&&<div style={{marginTop:'8mm'}}><div style={{fontWeight:600,fontSize:'10pt',marginBottom:'3mm',borderBottom:'.5pt solid #ddd',paddingBottom:'2mm'}}>Notes</div>{sorted.filter(v=>v.notes).map(v=>{const c=getCont(v.contact_id);return<div key={v.id} style={{marginBottom:'3mm',padding:'3mm',border:'.5pt solid #e8e8e8',borderRadius:'4pt',fontSize:'9pt'}}><strong>{fmtDate(v.date)} — {c.prenom} {c.nom}</strong><br/><span style={{color:'#666'}}>{v.notes}</span></div>})}</div>}
      <div className="ps-ft"><span>{visits.length} visite{visits.length>1?'s':''}</span><span>CRM Pro — {todayFr()}</span></div>
    </div>
  )
}

function PipelineDoc({ deals, getCont, getEnt }) {
  const stages=['Prospection','Qualifié','Proposition','Négociation','Gagné','Perdu']
  const total=deals.reduce((a,d)=>a+d.valeur,0)
  const sorted=[...deals].sort((a,b)=>stages.indexOf(a.etape)-stages.indexOf(b.etape))
  return (
    <div className="ps-doc">
      <div className="ps-hd"><Logo /><div><div className="ps-dt" style={{fontSize:'15pt'}}>PIPELINE COMMERCIAL</div><div className="ps-dr">{todayFr()}</div></div></div>
      <div className="ps-mt" style={{flexWrap:'wrap'}}>
        {['Prospection','Qualifié','Proposition','Négociation','Gagné'].map(s=>{const sd=deals.filter(d=>d.etape===s);const val=sd.reduce((a,d)=>a+d.valeur,0);return<div key={s} className="ps-mb" style={{flex:'1 1 auto',minWidth:'30mm'}}><div className="ps-ml">{s}</div><div className="ps-mv">{sd.length} deal{sd.length>1?'s':''}</div><div style={{fontSize:'8pt',color:'#666',marginTop:'1mm'}}>{fmtEur(val)}</div></div>})}
      </div>
      <table className="ps-tbl">
        <thead><tr><th>Deal</th><th>Contact</th><th>Entreprise</th><th>Étape</th><th className="c">Prob.</th><th className="r">Valeur</th><th>Resp.</th><th>Clôture</th></tr></thead>
        <tbody>{sorted.map(d=>{const c=getCont(d.contact_id);const e=getEnt(d.entreprise_id);return<tr key={d.id}><td style={{fontWeight:500}}>{d.nom}</td><td>{c.prenom} {c.nom}</td><td>{e.nom}</td><td><span className={`ps-st ${statusCls(d.etape)}`}>{d.etape}</span></td><td className="c">{d.prob}%</td><td className="r" style={{fontWeight:500}}>{fmtEur(d.valeur)}</td><td>{d.resp}</td><td style={{fontSize:'8.5pt',color:'#666'}}>{d.date_cloture||'—'}</td></tr>})}</tbody>
      </table>
      <div style={{textAlign:'right',fontWeight:700,fontSize:'11pt',marginTop:'4mm'}}>Valeur totale : {fmtEur(total)}</div>
      <div className="ps-ft"><span>{deals.length} deal{deals.length>1?'s':''}</span><span>CRM Pro — {todayFr()}</span></div>
    </div>
  )
}

const TITLES = {
  devis:    d => `Aperçu — Devis ${d?.devis?.ref||''}`,
  facture:  d => `Aperçu — Facture ${d?.facture?.ref||''}`,
  contacts: d => `Aperçu — ${d?.contacts?.length||0} contacts`,
  planning: d => `Aperçu — Planning (${d?.visits?.length||0} visites)`,
  pipeline: d => `Aperçu — Pipeline (${d?.deals?.length||0} deals)`,
}

export default function PrintSheet({ type, data, onClose }) {
  useEffect(() => {
    const id = 'crm-ps-css'
    if (!document.getElementById(id)) {
      const s = document.createElement('style')
      s.id = id; s.textContent = CSS
      document.head.appendChild(s)
    }
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = '' }
  }, [])

  useEffect(() => {
    const h = e => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  }, [onClose])

  return createPortal(
    <div className="ps-ov">
      <div className="ps-bar">
        <span className="ps-bar-t">{TITLES[type]?.(data)||'Aperçu'}</span>
        <button className="ps-bb" onClick={onClose}>✕ Fermer</button>
        <button className="ps-bb ps-bbp" onClick={()=>window.print()}>⎙ Imprimer / PDF</button>
      </div>
      {type==='devis'    && <DevisDoc    devis={data.devis}       entreprise={data.entreprise} />}
      {type==='facture'  && <FactureDoc  facture={data.facture}   entreprise={data.entreprise} devisRef={data.devisRef} />}
      {type==='contacts' && <ContactsDoc contacts={data.contacts} getEnt={data.getEnt}  filter={data.filter} />}
      {type==='planning' && <PlanningDoc visits={data.visits}     getCont={data.getCont} getEnt={data.getEnt} />}
      {type==='pipeline' && <PipelineDoc deals={data.deals}       getCont={data.getCont} getEnt={data.getEnt} />}
    </div>,
    document.body
  )
}
