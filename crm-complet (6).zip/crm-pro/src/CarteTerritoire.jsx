import { useEffect, useRef, useState } from 'react'

// Coordonnées Tréfumel 22630
const TREFUMEL = { lat: 48.3374, lng: -2.0242 }
const RAYON_KM = 10

// Communes dans le rayon de 20km (Côtes-d'Armor / Ille-et-Vilaine)
const COMMUNES_PROCHES = [
  { nom: 'Tréfumel', lat: 48.3374, lng: -2.0242, dist: 0, cp: '22630' },
  { nom: 'Évran', lat: 48.3667, lng: -2.0167, dist: 3.3, cp: '22630' },
  { nom: 'Le Quiou', lat: 48.3197, lng: -2.0011, dist: 2.0, cp: '22630' },
  { nom: 'Saint-Juvat', lat: 48.3558, lng: -2.0333, dist: 2.1, cp: '22630' },
  { nom: 'Plouasne', lat: 48.3025, lng: -2.0553, dist: 4.1, cp: '22830' },
  { nom: 'Saint-Maden', lat: 48.3100, lng: -1.9700, dist: 3.9, cp: '22350' },
  { nom: 'Guenroc', lat: 48.2867, lng: -2.0067, dist: 5.7, cp: '22350' },
  { nom: 'Dinan', lat: 48.4558, lng: -2.0497, dist: 13.2, cp: '22100' },
  { nom: 'Bécherel', lat: 48.3000, lng: -1.9333, dist: 7.8, cp: '35190' },
  { nom: 'Tinténiac', lat: 48.3333, lng: -1.8333, dist: 12.0, cp: '35190' },
  { nom: 'Hédé-Bazouges', lat: 48.3000, lng: -1.8167, dist: 13.9, cp: '35630' },
  { nom: 'Guitté', lat: 48.3000, lng: -2.1000, dist: 6.8, cp: '22350' },
  { nom: 'Saint-André-des-Eaux', lat: 48.3700, lng: -1.9800, dist: 3.9, cp: '22630' },
  { nom: 'Pleugueneuc', lat: 48.4167, lng: -1.9500, dist: 9.9, cp: '35720' },
  { nom: 'Lanvallay', lat: 48.4442, lng: -2.0217, dist: 11.9, cp: '22100' },
  { nom: 'Taden', lat: 48.4600, lng: -2.0600, dist: 13.8, cp: '22100' },
  { nom: 'Léhon', lat: 48.4403, lng: -2.0492, dist: 11.4, cp: '22100' },
  { nom: 'Saint-Solen', lat: 48.3997, lng: -2.0692, dist: 7.8, cp: '22100' },
  { nom: 'Trévron', lat: 48.3800, lng: -2.0800, dist: 6.9, cp: '22100' },
  { nom: 'Saint-Dominique', lat: 48.4100, lng: -2.0000, dist: 8.5, cp: '22350' },
]

function injectLeaflet(cb) {
  if (window.L) { cb(); return }
  const css = document.createElement('link')
  css.rel = 'stylesheet'
  css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
  document.head.appendChild(css)
  const js = document.createElement('script')
  js.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
  js.onload = cb
  document.head.appendChild(js)
}

export default function CarteTerritoire({ contacts, vis, ents }) {
  const mapRef = useRef(null)
  const mapInstance = useRef(null)
  const [showContacts, setShowContacts] = useState(true)
  const [showVisites, setShowVisites] = useState(true)
  const [showCommunes, setShowCommunes] = useState(true)
  const [selectedCommune, setSelectedCommune] = useState(null)

  useEffect(() => {
    injectLeaflet(() => {
      if (!mapRef.current || mapInstance.current) return
      const L = window.L

      const map = L.map(mapRef.current, {
        center: [TREFUMEL.lat, TREFUMEL.lng],
        zoom: 12,
        zoomControl: true,
      })
      mapInstance.current = map

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 18,
      }).addTo(map)

      // ── Cercle 20km ──────────────────────────────────────────────────────────
      L.circle([TREFUMEL.lat, TREFUMEL.lng], {
        radius: RAYON_KM * 1000,
        color: '#185FA5',
        weight: 2,
        dashArray: '8 6',
        fillColor: '#E6F1FB',
        fillOpacity: 0.15,
      }).addTo(map).bindPopup(`<b>Zone Tréfumel</b><br>Rayon : ${RAYON_KM} km`)

      // ── Marqueur central Tréfumel ─────────────────────────────────────────
      const pinIcon = L.divIcon({
        html: `<div style="width:14px;height:14px;background:#A32D2D;border:2px solid #fff;border-radius:50%;box-shadow:0 1px 4px rgba(0,0,0,.4)"></div>`,
        className: '', iconAnchor: [7, 7],
      })
      L.marker([TREFUMEL.lat, TREFUMEL.lng], { icon: pinIcon })
        .addTo(map)
        .bindPopup(`<b>Tréfumel</b> (22630)<br>Centre de la zone · Bretagne`)
        .openPopup()

      // Stocker la référence pour les layers dynamiques
      map._crmLayers = {}
    })

    return () => {
      if (mapInstance.current) {
        mapInstance.current.remove()
        mapInstance.current = null
      }
    }
  }, [])

  // ── Couche communes ────────────────────────────────────────────────────────
  useEffect(() => {
    const L = window.L
    if (!L || !mapInstance.current) return
    const map = mapInstance.current

    if (map._crmLayers.communes) {
      map._crmLayers.communes.forEach(m => m.remove())
    }
    if (!showCommunes) return

    const communeIcon = (isMain) => L.divIcon({
      html: `<div style="width:${isMain?12:8}px;height:${isMain?12:8}px;background:${isMain?'#A32D2D':'#534AB7'};border:2px solid #fff;border-radius:50%;box-shadow:0 1px 3px rgba(0,0,0,.35)"></div>`,
      className: '', iconAnchor: [isMain?6:4, isMain?6:4],
    })

    map._crmLayers.communes = COMMUNES_PROCHES.map(c => {
      const m = L.marker([c.lat, c.lng], { icon: communeIcon(c.dist === 0) })
        .addTo(map)
        .bindPopup(`<b>${c.nom}</b> (${c.cp})<br>${c.dist > 0 ? `à ${c.dist} km de Tréfumel` : 'Centre — Tréfumel'}`)
      return m
    })
  }, [showCommunes])

  // ── Couche contacts ────────────────────────────────────────────────────────
  useEffect(() => {
    const L = window.L
    if (!L || !mapInstance.current) return
    const map = mapInstance.current

    if (map._crmLayers.contacts) {
      map._crmLayers.contacts.forEach(m => m.remove())
    }
    if (!showContacts) return

    const contactsAvecCoords = contacts.filter(c => c.lat && c.lng)
    if (contactsAvecCoords.length === 0) {
      // Placer les contacts sur des communes de démo si pas de coords
      const demo = contacts.slice(0, Math.min(contacts.length, COMMUNES_PROCHES.length - 1))
      map._crmLayers.contacts = demo.map((c, i) => {
        const commune = COMMUNES_PROCHES[i + 1]
        if (!commune) return null
        const icon = L.divIcon({
          html: `<div style="width:28px;height:28px;background:#E6F1FB;border:2px solid #185FA5;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:600;color:#185FA5;box-shadow:0 1px 4px rgba(0,0,0,.3)">${c.av||'?'}</div>`,
          className: '', iconAnchor: [14, 14],
        })
        return L.marker([commune.lat + (Math.random()-0.5)*0.02, commune.lng + (Math.random()-0.5)*0.02], { icon })
          .addTo(map)
          .bindPopup(`<b>${c.prenom} ${c.nom}</b><br>${c.poste||''}<br><span style="color:#666">${ents?.find(e=>e.id===c.entreprise_id)?.nom||''}</span>`)
      }).filter(Boolean)
    }
  }, [showContacts, contacts])

  // ── Couche visites ─────────────────────────────────────────────────────────
  useEffect(() => {
    const L = window.L
    if (!L || !mapInstance.current) return
    const map = mapInstance.current

    if (map._crmLayers.visites) {
      map._crmLayers.visites.forEach(m => m.remove())
    }
    if (!showVisites) return

    const typeColor = { 'Visite client': '#3B6D11', 'Démo': '#185FA5', 'Prospection': '#854F0B', 'Autre': '#534AB7' }
    const visAvecCommune = vis.slice(0, Math.min(vis.length, COMMUNES_PROCHES.length - 1))

    map._crmLayers.visites = visAvecCommune.map((v, i) => {
      const commune = COMMUNES_PROCHES[i + 1]
      if (!commune) return null
      const color = typeColor[v.type] || '#534AB7'
      const icon = L.divIcon({
        html: `<div style="background:${color};color:#fff;padding:2px 6px;border-radius:4px;font-size:9px;font-weight:600;white-space:nowrap;box-shadow:0 1px 4px rgba(0,0,0,.35)">${v.type||'Visite'}</div>`,
        className: '', iconAnchor: [20, 10],
      })
      return L.marker([commune.lat + (Math.random()-0.5)*0.015, commune.lng + (Math.random()-0.5)*0.015], { icon })
        .addTo(map)
        .bindPopup(`<b>${v.type}</b><br>${v.date} · ${v.heure}<br><span style="color:#666">${v.lieu||commune.nom}</span><br>Resp : ${v.resp}`)
    }).filter(Boolean)
  }, [showVisites, vis])

  const communesInZone = COMMUNES_PROCHES.filter(c => c.dist <= RAYON_KM && c.dist > 0)
  const selC = selectedCommune ? COMMUNES_PROCHES.find(c => c.nom === selectedCommune) : null

  return (
    <div style={{ display: 'flex', gap: 14, height: 'calc(100vh - 110px)', minHeight: 500 }}>
      {/* Panneau gauche */}
      <div style={{ width: 240, minWidth: 240, display: 'flex', flexDirection: 'column', gap: 12 }}>

        {/* Info zone */}
        <div className="card" style={{ margin: 0 }}>
          <div className="card-title" style={{ marginBottom: 8 }}>Zone Tréfumel</div>
          <div style={{ fontSize: 12, color: 'var(--text2)', lineHeight: 1.7 }}>
            <div>📍 <b style={{ fontWeight: 500, color: 'var(--text1)' }}>Tréfumel</b> (22630)</div>
            <div>Lat : 48.3374 · Lng : -2.0242</div>
            <div>Rayon : <b style={{ fontWeight: 500, color: 'var(--text1)' }}>{RAYON_KM} km</b></div>
            <div style={{ marginTop: 6 }}>{communesInZone.length} communes dans la zone</div>
          </div>
        </div>

        {/* Filtres couches */}
        <div className="card" style={{ margin: 0 }}>
          <div className="card-title" style={{ marginBottom: 10 }}>Affichage</div>
          {[
            { label: 'Communes', state: showCommunes, set: setShowCommunes, color: '#534AB7' },
            { label: `Contacts (${contacts.length})`, state: showContacts, set: setShowContacts, color: '#185FA5' },
            { label: `Visites (${vis.length})`, state: showVisites, set: setShowVisites, color: '#3B6D11' },
          ].map(({ label, state, set, color }) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, cursor: 'pointer' }} onClick={() => set(!state)}>
              <div style={{ width: 14, height: 14, borderRadius: 3, background: state ? color : 'var(--bg2)', border: `1.5px solid ${color}`, flexShrink: 0, transition: 'background .15s' }} />
              <span style={{ fontSize: 12, color: 'var(--text1)' }}>{label}</span>
            </div>
          ))}
        </div>

        {/* Liste communes */}
        <div className="card" style={{ margin: 0, flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          <div className="card-title" style={{ marginBottom: 8 }}>Communes proches</div>
          <div style={{ overflow: 'auto', flex: 1 }}>
            {COMMUNES_PROCHES.filter(c => c.dist > 0).sort((a, b) => a.dist - b.dist).map(c => (
              <div
                key={c.nom}
                style={{
                  padding: '6px 8px', borderRadius: 'var(--radius-md)', marginBottom: 3,
                  cursor: 'pointer', fontSize: 12,
                  background: selectedCommune === c.nom ? 'var(--bg2)' : 'transparent',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}
                onClick={() => {
                  setSelectedCommune(selectedCommune === c.nom ? null : c.nom)
                  if (mapInstance.current) {
                    mapInstance.current.setView([c.lat, c.lng], 13)
                  }
                }}
              >
                <span style={{ color: 'var(--text1)' }}>{c.nom}</span>
                <span style={{ color: 'var(--text2)', fontSize: 10 }}>{c.dist} km</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Carte */}
      <div style={{ flex: 1, borderRadius: 'var(--radius-lg)', overflow: 'hidden', border: '0.5px solid var(--border1)', position: 'relative' }}>
        <div ref={mapRef} style={{ width: '100%', height: '100%' }} />
        {/* Badge rayon */}
        <div style={{
          position: 'absolute', bottom: 24, right: 10, zIndex: 1000,
          background: 'var(--bg1)', border: '0.5px solid var(--border1)',
          borderRadius: 'var(--radius-md)', padding: '6px 10px',
          fontSize: 11, color: 'var(--text2)', boxShadow: '0 1px 6px rgba(0,0,0,.12)',
        }}>
          <span style={{ color: '#185FA5', fontWeight: 500 }}>●</span> Cercle {RAYON_KM} km · Tréfumel 22630
        </div>
      </div>
    </div>
  )
}
