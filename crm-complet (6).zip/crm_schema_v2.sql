-- ============================================
-- CRM Pro v2 — Schéma MySQL complet
-- Inclut : contacts, entreprises, deals,
--          activités, visites, devis, factures
-- ============================================

CREATE DATABASE IF NOT EXISTS crm_pro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE crm_pro;

-- ============================================
-- ENTREPRISES
-- ============================================
CREATE TABLE entreprises (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nom         VARCHAR(150) NOT NULL,
  secteur     VARCHAR(100),
  statut      ENUM('Actif','Prospect','Inactif') DEFAULT 'Prospect',
  ville       VARCHAR(150),
  site_web    VARCHAR(255),
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- CONTACTS
-- ============================================
CREATE TABLE contacts (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  prenom         VARCHAR(100) NOT NULL,
  nom            VARCHAR(100) NOT NULL,
  email          VARCHAR(200) UNIQUE,
  telephone      VARCHAR(30),
  poste          VARCHAR(150),
  statut         ENUM('Actif','Client','Prospect','Inactif') DEFAULT 'Prospect',
  responsable    VARCHAR(100),
  entreprise_id  INT,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE SET NULL
);

-- ============================================
-- DEALS (PIPELINE)
-- ============================================
CREATE TABLE deals (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  nom            VARCHAR(200) NOT NULL,
  valeur         DECIMAL(12,2) DEFAULT 0,
  probabilite    TINYINT UNSIGNED DEFAULT 0,
  etape          ENUM('Prospection','Qualifié','Proposition','Négociation','Gagné','Perdu') DEFAULT 'Prospection',
  contact_id     INT,
  entreprise_id  INT,
  responsable    VARCHAR(100),
  date_cloture   DATE,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_prob CHECK (probabilite BETWEEN 0 AND 100),
  FOREIGN KEY (contact_id)    REFERENCES contacts(id)    ON DELETE SET NULL,
  FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE SET NULL
);

-- ============================================
-- ACTIVITÉS
-- ============================================
CREATE TABLE activites (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  type           ENUM('Email','Appel','Réunion','Tâche','Note') NOT NULL,
  titre          VARCHAR(200) NOT NULL,
  description    TEXT,
  statut         ENUM('Planifiée','Terminée','Annulée') DEFAULT 'Planifiée',
  date_activite  DATE NOT NULL,
  heure          TIME DEFAULT '09:00:00',
  contact_id     INT,
  deal_id        INT,
  responsable    VARCHAR(100),
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL,
  FOREIGN KEY (deal_id)    REFERENCES deals(id)    ON DELETE SET NULL
);

-- ============================================
-- PLANNING VISITES
-- ============================================
CREATE TABLE visites (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  date_visite    DATE NOT NULL,
  heure          TIME NOT NULL DEFAULT '10:00:00',
  contact_id     INT,
  entreprise_id  INT,
  type           ENUM('Visite client','Démo','Prospection','Autre') DEFAULT 'Visite client',
  lieu           VARCHAR(255),
  statut         ENUM('Confirmée','En attente','Annulée') DEFAULT 'En attente',
  responsable    VARCHAR(100),
  notes          TEXT,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (contact_id)    REFERENCES contacts(id)    ON DELETE SET NULL,
  FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE SET NULL
);

-- ============================================
-- DEVIS
-- ============================================
CREATE TABLE devis (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  reference      VARCHAR(20) UNIQUE NOT NULL,
  contact_id     INT,
  entreprise_id  INT,
  statut         ENUM('En attente','Accepté','Refusé','Expiré') DEFAULT 'En attente',
  date_emission  DATE NOT NULL,
  date_validite  DATE NOT NULL,
  montant_ht     DECIMAL(12,2) DEFAULT 0,
  taux_tva       DECIMAL(5,2)  DEFAULT 20.00,
  montant_ttc    DECIMAL(12,2) GENERATED ALWAYS AS (montant_ht * (1 + taux_tva / 100)) STORED,
  notes          TEXT,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (contact_id)    REFERENCES contacts(id)    ON DELETE SET NULL,
  FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE SET NULL
);

-- Lignes de devis
CREATE TABLE devis_lignes (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  devis_id        INT NOT NULL,
  description     VARCHAR(255) NOT NULL,
  quantite        DECIMAL(10,2) DEFAULT 1,
  prix_unitaire_ht DECIMAL(12,2) NOT NULL,
  total_ht        DECIMAL(12,2) GENERATED ALWAYS AS (quantite * prix_unitaire_ht) STORED,
  FOREIGN KEY (devis_id) REFERENCES devis(id) ON DELETE CASCADE
);

-- ============================================
-- FACTURES
-- ============================================
CREATE TABLE factures (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  reference      VARCHAR(20) UNIQUE NOT NULL,
  devis_id       INT,
  contact_id     INT,
  entreprise_id  INT,
  statut         ENUM('En attente','Payée','En retard','Annulée') DEFAULT 'En attente',
  date_emission  DATE NOT NULL,
  date_echeance  DATE NOT NULL,
  date_paiement  DATE,
  montant_ht     DECIMAL(12,2) DEFAULT 0,
  taux_tva       DECIMAL(5,2)  DEFAULT 20.00,
  montant_ttc    DECIMAL(12,2) GENERATED ALWAYS AS (montant_ht * (1 + taux_tva / 100)) STORED,
  notes          TEXT,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (devis_id)      REFERENCES devis(id)       ON DELETE SET NULL,
  FOREIGN KEY (contact_id)    REFERENCES contacts(id)    ON DELETE SET NULL,
  FOREIGN KEY (entreprise_id) REFERENCES entreprises(id) ON DELETE SET NULL
);

-- Lignes de factures
CREATE TABLE factures_lignes (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  facture_id       INT NOT NULL,
  description      VARCHAR(255) NOT NULL,
  quantite         DECIMAL(10,2) DEFAULT 1,
  prix_unitaire_ht DECIMAL(12,2) NOT NULL,
  total_ht         DECIMAL(12,2) GENERATED ALWAYS AS (quantite * prix_unitaire_ht) STORED,
  FOREIGN KEY (facture_id) REFERENCES factures(id) ON DELETE CASCADE
);

-- ============================================
-- DONNÉES DE DÉMONSTRATION
-- ============================================

INSERT INTO entreprises (nom, secteur, statut, ville, site_web) VALUES
('Renault',       'Automobile',    'Actif',    'Boulogne-Billancourt', 'https://renault.fr'),
('LVMH',          'Luxe',          'Actif',    'Paris',               'https://lvmh.com'),
('Airbus',        'Aéronautique',  'Actif',    'Toulouse',            'https://airbus.com'),
('Orange',        'Télécoms',      'Prospect', 'Paris',               'https://orange.fr'),
('TotalEnergies', 'Énergie',       'Actif',    'Courbevoie',          'https://totalenergies.com');

INSERT INTO contacts (prenom, nom, email, telephone, poste, statut, responsable, entreprise_id) VALUES
('Marie',  'Dupont',  'm.dupont@renault.fr',   '+33 6 12 34 56 78', 'Directrice Marketing', 'Actif',    'Thomas', 1),
('Jean',   'Martin',  'j.martin@lvmh.com',     '+33 6 98 76 54 32', 'DSI',                  'Actif',    'Lucie',  2),
('Sophie', 'Leclerc', 's.leclerc@airbus.com',  '+33 6 55 44 33 22', 'Responsable Achats',   'Client',   'Thomas', 3),
('Pierre', 'Bernard', 'p.bernard@orange.fr',   '+33 6 11 22 33 44', 'Chef de Projet',       'Prospect', 'Marc',   4),
('Claire', 'Moreau',  'c.moreau@renault.fr',   '+33 6 77 88 99 00', 'Acheteuse',            'Client',   'Thomas', 1),
('Lucas',  'Simon',   'l.simon@total.fr',      '+33 6 44 55 66 77', 'Manager IT',           'Prospect', 'Emma',   5),
('Emma',   'Petit',   'e.petit@lvmh.com',      '+33 6 33 22 11 00', 'Chef de compte',       'Actif',    'Lucie',  2),
('Romain', 'Leroy',   'r.leroy@airbus.com',    '+33 6 66 77 88 99', 'Ingénieur Systèmes',   'Inactif',  'Marc',   3);

INSERT INTO deals (nom, valeur, probabilite, etape, contact_id, entreprise_id, responsable, date_cloture) VALUES
('Achat SaaS Renault',       45000,  80,  'Négociation', 1, 1, 'Thomas', '2026-04-30'),
('Renouvellement LVMH',     120000,  60,  'Proposition', 2, 2, 'Lucie',  '2026-05-15'),
('Contrat Airbus',           80000, 100,  'Gagné',       3, 3, 'Thomas', '2026-03-31'),
('Upgrade Orange',           22000,  40,  'Qualifié',    4, 4, 'Marc',   '2026-06-01'),
('Expansion TotalEnergies',  35000,  20,  'Prospection', 6, 5, 'Emma',   '2026-07-01');

INSERT INTO activites (type, titre, description, statut, date_activite, heure, contact_id, responsable) VALUES
('Réunion', 'Réunion Sophie Leclerc',   'Présentation de la nouvelle offre', 'Planifiée', '2026-04-09', '14:00', 3, 'Thomas'),
('Email',   'Suivi Jean Martin',         NULL,                                'Planifiée', '2026-04-10', '09:00', 2, 'Lucie'),
('Appel',   'Démo Pierre Bernard',       NULL,                                'Planifiée', '2026-04-10', '11:00', 4, 'Marc'),
('Email',   'Envoi proposition Renault', NULL,                                'Terminée',  '2026-04-07', '10:00', 1, 'Thomas'),
('Appel',   'Qualif. Lucas Simon',       'Durée : 25 min',                    'Terminée',  '2026-04-06', '15:00', 6, 'Emma');

INSERT INTO visites (date_visite, heure, contact_id, entreprise_id, type, lieu, statut, responsable, notes) VALUES
('2026-04-09', '14:00', 3, 3, 'Visite client', 'Toulouse — Airbus HQ',         'Confirmée',  'Thomas', 'Présentation offre Q2'),
('2026-04-11', '10:00', 1, 1, 'Démo',          'Boulogne — Renault HQ',        'Confirmée',  'Thomas', ''),
('2026-04-15', '09:30', 2, 2, 'Visite client', 'Paris — LVMH siège',           'En attente', 'Lucie',  'Négociation renouvellement'),
('2026-04-17', '14:00', 4, 4, 'Prospection',   'Paris — Orange siège',         'En attente', 'Marc',   ''),
('2026-04-22', '11:00', 6, 5, 'Démo',          'Courbevoie — TotalEnergies',   'Confirmée',  'Emma',   ''),
('2026-04-28', '15:00', 5, 1, 'Visite client', 'Boulogne — Renault (Claire)',  'Confirmée',  'Thomas', 'Renouvellement contrat annuel');

INSERT INTO devis (reference, contact_id, entreprise_id, statut, date_emission, date_validite, montant_ht, notes) VALUES
('DEV-024', 1, 1, 'En attente', '2026-03-25', '2026-04-25', 45000.00, NULL),
('DEV-023', 2, 2, 'Accepté',    '2026-03-18', '2026-04-18', 120000.00, NULL),
('DEV-022', 4, 4, 'En attente', '2026-03-10', '2026-04-10', 22000.00, NULL),
('DEV-021', 3, 3, 'Accepté',    '2026-03-01', '2026-04-01', 80000.00, NULL),
('DEV-020', 6, 5, 'Refusé',     '2026-02-20', '2026-03-20', 35000.00, NULL);

INSERT INTO devis_lignes (devis_id, description, quantite, prix_unitaire_ht) VALUES
(1, 'Licence SaaS annuelle',  1, 40000.00),
(1, 'Formation utilisateurs', 2,  2500.00),
(2, 'Plateforme Enterprise',  1, 100000.00),
(2, 'Support Premium',        1,  20000.00),
(3, 'Module Télécoms',        2,   9000.00),
(3, 'Intégration API',        1,   4000.00),
(4, 'Suite Aéronautique',     1,  75000.00),
(4, 'Maintenance annuelle',   1,   5000.00),
(5, 'Module Énergie',         1,  35000.00);

INSERT INTO factures (reference, devis_id, contact_id, entreprise_id, statut, date_emission, date_echeance, montant_ht) VALUES
('FAC-031', 4, 3, 3, 'Payée',      '2026-03-08', '2026-04-15',  80000.00),
('FAC-030', 2, 2, 2, 'En retard',  '2026-03-18', '2026-04-01', 120000.00),
('FAC-029', 1, 1, 1, 'En attente', '2026-03-25', '2026-04-20',  22500.00);

INSERT INTO factures_lignes (facture_id, description, quantite, prix_unitaire_ht) VALUES
(1, 'Suite Aéronautique',    1, 75000.00),
(1, 'Maintenance annuelle',  1,  5000.00),
(2, 'Plateforme Enterprise', 1, 100000.00),
(2, 'Support Premium',       1,  20000.00),
(3, 'Licence SaaS annuelle', 1,  40000.00),
(3, 'Formation',             1,   2500.00),
(3, 'Remise commerciale',    1, -20000.00);

-- ============================================
-- VUES UTILES
-- ============================================

CREATE OR REPLACE VIEW v_contacts_full AS
SELECT c.*, e.nom AS entreprise_nom, e.secteur, e.ville
FROM contacts c
LEFT JOIN entreprises e ON c.entreprise_id = e.id;

CREATE OR REPLACE VIEW v_visites_full AS
SELECT v.*,
  CONCAT(c.prenom, ' ', c.nom) AS contact_nom,
  e.nom AS entreprise_nom
FROM visites v
LEFT JOIN contacts c    ON v.contact_id    = c.id
LEFT JOIN entreprises e ON v.entreprise_id = e.id;

CREATE OR REPLACE VIEW v_dashboard AS
SELECT
  (SELECT COUNT(*) FROM contacts)                                   AS nb_contacts,
  (SELECT COUNT(*) FROM deals WHERE etape NOT IN ('Gagné','Perdu')) AS nb_deals_actifs,
  (SELECT COUNT(*) FROM visites WHERE MONTH(date_visite)=MONTH(CURDATE()) AND YEAR(date_visite)=YEAR(CURDATE())) AS visites_ce_mois,
  (SELECT COUNT(*) FROM devis   WHERE statut='En attente')          AS devis_en_attente,
  (SELECT COALESCE(SUM(montant_ht),0) FROM devis WHERE statut='En attente') AS valeur_devis_attente,
  (SELECT COALESCE(SUM(montant_ttc),0) FROM factures WHERE statut='En retard') AS factures_en_retard;
