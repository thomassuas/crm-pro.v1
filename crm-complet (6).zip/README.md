# CRM Pro — Guide de démarrage

## Structure du projet

```
crm-pro/          ← Frontend React + Vite
crm-backend/      ← API Express + MySQL
crm_schema_v2.sql ← Schéma + données de démo
```

---

## 1. Base de données MySQL

```bash
# Importer le schéma et les données de démo
mysql -u root -p < crm_schema_v2.sql
```

---

## 2. Backend (API Express)

```bash
cd crm-backend
npm install
```

Éditer `crm-backend/.env` :
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=VOTRE_MOT_DE_PASSE
DB_NAME=crm_pro
PORT=4000
FRONTEND_URL=*
```

```bash
npm start        # production
npm run dev      # développement (nodemon)
```

Vérifier :
```
GET http://localhost:4000/api/health
→ { "status": "ok", "db": "connected" }
```

---

## 3. Frontend (React + Vite)

Éditer `crm-pro/.env` selon votre environnement :

```bash
# Développement local
VITE_API_URL=http://localhost:4000/api

# Hébergement mutualisé (Hostinger, OVH, etc.)
# si frontend et backend sur le même domaine :
VITE_API_URL=https://votre-domaine.com/api

# Si backend sur sous-domaine
VITE_API_URL=https://api.votre-domaine.com/api
```

```bash
cd crm-pro
npm install
npm run build    # génère le dossier dist/ à déployer
```

---

## 4. Déploiement Hostinger (hébergement mutualisé)

### Frontend
1. `npm run build` dans `crm-pro/`
2. Uploader le contenu de `crm-pro/dist/` dans `public_html/`
3. Créer un `.htaccess` dans `public_html/` :
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

### Backend (Node.js sur Hostinger)
1. Uploader `crm-backend/` dans un dossier séparé (ex: `backend/`)
2. Dans le panneau Hostinger > Node.js : pointer vers `server.js`
3. Configurer les variables d'environnement dans le panneau
4. Mettre `VITE_API_URL=https://votre-domaine.com/api` dans le `.env` du frontend avant le build

### Résolution des erreurs "Failed to fetch"
- Vérifier que `VITE_API_URL` pointe vers la bonne URL dans `crm-pro/.env`
- Vérifier que le backend est bien démarré (`/api/health` doit répondre)
- Vérifier que le port du backend est ouvert dans le pare-feu
- En cas de HTTPS/HTTP mixte : frontend et backend doivent tous deux être en HTTPS

---

## Endpoints API

| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/health` | Statut MySQL |
| GET | `/api/dashboard` | Métriques globales |
| GET/POST | `/api/contacts` | Liste / Créer |
| PUT/DELETE | `/api/contacts/:id` | Modifier / Supprimer |
| GET/POST | `/api/entreprises` | Liste / Créer |
| PUT/DELETE | `/api/entreprises/:id` | Modifier / Supprimer |
| GET/POST | `/api/deals` | Liste / Créer |
| PUT/DELETE | `/api/deals/:id` | Modifier / Supprimer |
| GET/POST | `/api/activites` | Liste / Créer |
| DELETE | `/api/activites/:id` | Supprimer |
| GET/POST | `/api/visites` | Liste / Créer |
| PUT/DELETE | `/api/visites/:id` | Modifier / Supprimer |
| GET/POST | `/api/devis` | Liste / Créer |
| POST | `/api/devis/:id/convertir` | → Facture |
| GET/POST | `/api/factures` | Liste / Créer |
| PUT | `/api/factures/:id/payer` | Marquer payée |


## Structure du projet

```
crm-pro/          ← Frontend React + Vite
crm-backend/      ← API Express + MySQL
crm_schema_v2.sql ← Schéma + données de démo
```

---

## 1. Base de données MySQL

```bash
# Importer le schéma et les données de démo
mysql -u root -p < crm_schema_v2.sql
```

---

## 2. Backend (API Express)

```bash
cd crm-backend
npm install

# Configurer la connexion MySQL
cp .env .env.local   # ou éditer .env directement
```

Éditer `.env` :
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=VOTRE_MOT_DE_PASSE
DB_NAME=crm_pro
PORT=4000
FRONTEND_URL=http://localhost:5173
```

```bash
# Démarrer l'API
npm start            # production
npm run dev          # développement (avec nodemon)
```

Vérifier que l'API fonctionne :
```
GET http://localhost:4000/api/health
→ { "status": "ok", "db": "connected" }
```

---

## 3. Frontend (React + Vite)

```bash
cd crm-pro
npm install

# L'URL de l'API est déjà configurée dans .env
# VITE_API_URL=http://localhost:4000/api

npm run dev          # développement → http://localhost:5173
npm run build        # production → dossier dist/
```

---

## 4. Déploiement production

### Frontend (Vercel / Netlify)
```bash
cd crm-pro && npm run build
# Déployer le dossier dist/
# Ajouter la variable d'environnement : VITE_API_URL=https://votre-api.com/api
```

### Backend (VPS / Railway / Render)
```bash
cd crm-backend && npm start
# Variables d'environnement à configurer sur le serveur
```

---

## Endpoints API disponibles

| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/health` | Statut de connexion MySQL |
| GET | `/api/dashboard` | Métriques globales |
| GET/POST | `/api/contacts` | Liste / Créer |
| PUT/DELETE | `/api/contacts/:id` | Modifier / Supprimer |
| GET/POST | `/api/entreprises` | Liste / Créer |
| PUT/DELETE | `/api/entreprises/:id` | Modifier / Supprimer |
| GET/POST | `/api/deals` | Liste / Créer |
| PUT/DELETE | `/api/deals/:id` | Modifier / Supprimer |
| GET/POST | `/api/activites` | Liste / Créer |
| DELETE | `/api/activites/:id` | Supprimer |
| GET/POST | `/api/visites` | Liste / Créer |
| PUT/DELETE | `/api/visites/:id` | Modifier / Supprimer |
| GET/POST | `/api/devis` | Liste / Créer (avec lignes) |
| POST | `/api/devis/:id/convertir` | Convertir en facture |
| GET/POST | `/api/factures` | Liste / Créer |
| PUT | `/api/factures/:id/payer` | Marquer comme payée |
