const router = require('express').Router()
const db = require('../db')

// GET toutes
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT e.*,
        COUNT(DISTINCT c.id) AS nb_contacts,
        COUNT(DISTINCT d.id) AS nb_deals
      FROM entreprises e
      LEFT JOIN contacts c ON c.entreprise_id = e.id
      LEFT JOIN deals d    ON d.entreprise_id = e.id AND d.etape NOT IN ('Gagné','Perdu')
      GROUP BY e.id ORDER BY e.nom
    `)
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// GET une
router.get('/:id', async (req, res) => {
  try {
    const [[row]] = await db.execute('SELECT * FROM entreprises WHERE id=?', [req.params.id])
    if (!row) return res.status(404).json({ error: 'Introuvable' })
    res.json(row)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// POST créer
router.post('/', async (req, res) => {
  try {
    const { nom, secteur, statut, ville, site_web } = req.body
    const [r] = await db.execute(
      'INSERT INTO entreprises (nom,secteur,statut,ville,site_web) VALUES (?,?,?,?,?)',
      [nom, secteur||null, statut||'Prospect', ville||null, site_web||null]
    )
    const [[created]] = await db.execute('SELECT * FROM entreprises WHERE id=?', [r.insertId])
    res.status(201).json(created)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// PUT modifier
router.put('/:id', async (req, res) => {
  try {
    const { nom, secteur, statut, ville, site_web } = req.body
    await db.execute(
      'UPDATE entreprises SET nom=?,secteur=?,statut=?,ville=?,site_web=? WHERE id=?',
      [nom, secteur||null, statut||'Prospect', ville||null, site_web||null, req.params.id]
    )
    const [[updated]] = await db.execute('SELECT * FROM entreprises WHERE id=?', [req.params.id])
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// DELETE
router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM entreprises WHERE id=?', [req.params.id])
    res.json({ ok: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
