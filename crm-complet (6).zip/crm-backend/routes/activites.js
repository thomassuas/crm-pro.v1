const router = require('express').Router()
const db = require('../db')

router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT a.*, CONCAT(c.prenom,' ',c.nom) AS contact_nom
      FROM activites a
      LEFT JOIN contacts c ON a.contact_id = c.id
      ORDER BY a.date_activite DESC, a.heure DESC
    `)
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.post('/', async (req, res) => {
  try {
    const { type, titre, description, statut, date_activite, heure, contact_id, deal_id, responsable } = req.body
    const [r] = await db.execute(
      'INSERT INTO activites (type,titre,description,statut,date_activite,heure,contact_id,deal_id,responsable) VALUES (?,?,?,?,?,?,?,?,?)',
      [type||'Email', titre, description||null, statut||'Planifiée', date_activite, heure||'09:00', contact_id||null, deal_id||null, responsable||null]
    )
    const [[created]] = await db.execute(
      'SELECT a.*, CONCAT(c.prenom," ",c.nom) AS contact_nom FROM activites a LEFT JOIN contacts c ON a.contact_id=c.id WHERE a.id=?',
      [r.insertId]
    )
    res.status(201).json(created)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.put('/:id', async (req, res) => {
  try {
    const { type, titre, description, statut, date_activite, heure, contact_id, deal_id, responsable } = req.body
    await db.execute(
      'UPDATE activites SET type=?,titre=?,description=?,statut=?,date_activite=?,heure=?,contact_id=?,deal_id=?,responsable=? WHERE id=?',
      [type, titre, description||null, statut, date_activite, heure, contact_id||null, deal_id||null, responsable||null, req.params.id]
    )
    const [[updated]] = await db.execute('SELECT * FROM activites WHERE id=?', [req.params.id])
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM activites WHERE id=?', [req.params.id])
    res.json({ ok: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
