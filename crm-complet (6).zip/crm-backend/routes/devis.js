const router = require('express').Router()
const db = require('../db')

router.get('/', async (req, res) => {
  try {
    const { statut } = req.query
    let sql = `SELECT dv.*, e.nom AS entreprise_nom FROM devis dv LEFT JOIN entreprises e ON dv.entreprise_id=e.id`
    const params = []
    if (statut && statut !== 'tous') { sql += ' WHERE dv.statut=?'; params.push(statut) }
    sql += ' ORDER BY dv.date_emission DESC'
    const [rows] = await db.execute(sql, params)
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.get('/:id', async (req, res) => {
  try {
    const [[devis]] = await db.execute(
      'SELECT dv.*, e.nom AS entreprise_nom FROM devis dv LEFT JOIN entreprises e ON dv.entreprise_id=e.id WHERE dv.id=?',
      [req.params.id]
    )
    if (!devis) return res.status(404).json({ error: 'Introuvable' })
    const [lignes] = await db.execute('SELECT * FROM devis_lignes WHERE devis_id=? ORDER BY id', [req.params.id])
    res.json({ ...devis, items: lignes.map(l => ({ desc: l.description, qty: l.quantite, pu: l.prix_unitaire_ht })) })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.post('/', async (req, res) => {
  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const { entreprise_id, contact_id, statut, date_emission, date_validite, notes, items } = req.body
    const montant_ht = (items||[]).reduce((s, l) => s + (l.qty * l.pu), 0)

    // Auto-référence
    const [[{ count }]] = await conn.execute('SELECT COUNT(*) AS count FROM devis')
    const reference = `DEV-${String(count + 1).padStart(3, '0')}`

    const [r] = await conn.execute(
      'INSERT INTO devis (reference,entreprise_id,contact_id,statut,date_emission,date_validite,montant_ht,notes) VALUES (?,?,?,?,?,?,?,?)',
      [reference, entreprise_id||null, contact_id||null, statut||'En attente', date_emission, date_validite, montant_ht, notes||null]
    )
    for (const l of (items||[])) {
      await conn.execute(
        'INSERT INTO devis_lignes (devis_id,description,quantite,prix_unitaire_ht) VALUES (?,?,?,?)',
        [r.insertId, l.desc, l.qty, l.pu]
      )
    }
    await conn.commit()

    const [[created]] = await conn.execute(
      'SELECT dv.*, e.nom AS entreprise_nom FROM devis dv LEFT JOIN entreprises e ON dv.entreprise_id=e.id WHERE dv.id=?',
      [r.insertId]
    )
    const [lignes] = await conn.execute('SELECT * FROM devis_lignes WHERE devis_id=?', [r.insertId])
    res.status(201).json({ ...created, items: lignes.map(l => ({ desc: l.description, qty: l.quantite, pu: l.prix_unitaire_ht })) })
  } catch (err) {
    await conn.rollback()
    res.status(500).json({ error: err.message })
  } finally { conn.release() }
})

router.put('/:id/statut', async (req, res) => {
  try {
    await db.execute('UPDATE devis SET statut=? WHERE id=?', [req.body.statut, req.params.id])
    const [[updated]] = await db.execute('SELECT * FROM devis WHERE id=?', [req.params.id])
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// Convertir en facture
router.post('/:id/convertir', async (req, res) => {
  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const [[devis]] = await conn.execute('SELECT * FROM devis WHERE id=?', [req.params.id])
    if (!devis) return res.status(404).json({ error: 'Devis introuvable' })

    const [[{ count }]] = await conn.execute('SELECT COUNT(*) AS count FROM factures')
    const reference = `FAC-${String(count + 1).padStart(3, '0')}`
    const date_echeance = req.body.date_echeance || new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0]

    const [r] = await conn.execute(
      'INSERT INTO factures (reference,devis_id,contact_id,entreprise_id,statut,date_emission,date_echeance,montant_ht) VALUES (?,?,?,?,?,CURDATE(),?,?)',
      [reference, devis.id, devis.contact_id, devis.entreprise_id, 'En attente', date_echeance, devis.montant_ht]
    )
    const [lignes] = await conn.execute('SELECT * FROM devis_lignes WHERE devis_id=?', [devis.id])
    for (const l of lignes) {
      await conn.execute(
        'INSERT INTO factures_lignes (facture_id,description,quantite,prix_unitaire_ht) VALUES (?,?,?,?)',
        [r.insertId, l.description, l.quantite, l.prix_unitaire_ht]
      )
    }
    await conn.execute("UPDATE devis SET statut='Accepté' WHERE id=?", [devis.id])
    await conn.commit()
    res.status(201).json({ id: r.insertId, reference, message: 'Facture créée' })
  } catch (err) {
    await conn.rollback()
    res.status(500).json({ error: err.message })
  } finally { conn.release() }
})

router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM devis WHERE id=?', [req.params.id])
    res.json({ ok: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
