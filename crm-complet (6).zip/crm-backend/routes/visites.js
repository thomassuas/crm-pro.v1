const router = require('express').Router()
const db = require('../db')

router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT v.*, CONCAT(c.prenom,' ',c.nom) AS contact_nom, e.nom AS entreprise_nom
      FROM visites v
      LEFT JOIN contacts c    ON v.contact_id    = c.id
      LEFT JOIN entreprises e ON v.entreprise_id = e.id
      ORDER BY v.date_visite ASC, v.heure ASC
    `)
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.post('/', async (req, res) => {
  try {
    const { date_visite, heure, contact_id, entreprise_id, type, lieu, statut, responsable, notes } = req.body
    const [r] = await db.execute(
      'INSERT INTO visites (date_visite,heure,contact_id,entreprise_id,type,lieu,statut,responsable,notes) VALUES (?,?,?,?,?,?,?,?,?)',
      [date_visite, heure||'10:00', contact_id||null, entreprise_id||null, type||'Visite client', lieu||null, statut||'En attente', responsable||null, notes||null]
    )
    const [[created]] = await db.execute(
      'SELECT v.*, CONCAT(c.prenom," ",c.nom) AS contact_nom, e.nom AS entreprise_nom FROM visites v LEFT JOIN contacts c ON v.contact_id=c.id LEFT JOIN entreprises e ON v.entreprise_id=e.id WHERE v.id=?',
      [r.insertId]
    )
    res.status(201).json(created)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.put('/:id', async (req, res) => {
  try {
    const { date_visite, heure, contact_id, entreprise_id, type, lieu, statut, responsable, notes } = req.body
    await db.execute(
      'UPDATE visites SET date_visite=?,heure=?,contact_id=?,entreprise_id=?,type=?,lieu=?,statut=?,responsable=?,notes=? WHERE id=?',
      [date_visite, heure, contact_id||null, entreprise_id||null, type, lieu||null, statut, responsable||null, notes||null, req.params.id]
    )
    const [[updated]] = await db.execute('SELECT * FROM visites WHERE id=?', [req.params.id])
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM visites WHERE id=?', [req.params.id])
    res.json({ ok: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
