const router = require('express').Router()
const db = require('../db')

router.get('/', async (req, res) => {
  try {
    const { statut } = req.query
    let sql = `SELECT c.*, e.nom AS entreprise_nom FROM contacts c
               LEFT JOIN entreprises e ON c.entreprise_id = e.id`
    const params = []
    if (statut && statut !== 'tous') { sql += ' WHERE c.statut=?'; params.push(statut) }
    sql += ' ORDER BY c.nom, c.prenom'
    const [rows] = await db.execute(sql, params)
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.get('/:id', async (req, res) => {
  try {
    const [[row]] = await db.execute(
      'SELECT c.*, e.nom AS entreprise_nom FROM contacts c LEFT JOIN entreprises e ON c.entreprise_id=e.id WHERE c.id=?',
      [req.params.id]
    )
    if (!row) return res.status(404).json({ error: 'Introuvable' })
    res.json(row)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.post('/', async (req, res) => {
  try {
    const { prenom, nom, email, telephone, poste, statut, responsable, entreprise_id } = req.body
    const [r] = await db.execute(
      'INSERT INTO contacts (prenom,nom,email,telephone,poste,statut,responsable,entreprise_id) VALUES (?,?,?,?,?,?,?,?)',
      [prenom, nom, email||null, telephone||null, poste||null, statut||'Prospect', responsable||null, entreprise_id||null]
    )
    const [[created]] = await db.execute(
      'SELECT c.*, e.nom AS entreprise_nom FROM contacts c LEFT JOIN entreprises e ON c.entreprise_id=e.id WHERE c.id=?',
      [r.insertId]
    )
    res.status(201).json(created)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.put('/:id', async (req, res) => {
  try {
    const { prenom, nom, email, telephone, poste, statut, responsable, entreprise_id } = req.body
    await db.execute(
      'UPDATE contacts SET prenom=?,nom=?,email=?,telephone=?,poste=?,statut=?,responsable=?,entreprise_id=? WHERE id=?',
      [prenom, nom, email||null, telephone||null, poste||null, statut||'Prospect', responsable||null, entreprise_id||null, req.params.id]
    )
    const [[updated]] = await db.execute(
      'SELECT c.*, e.nom AS entreprise_nom FROM contacts c LEFT JOIN entreprises e ON c.entreprise_id=e.id WHERE c.id=?',
      [req.params.id]
    )
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM contacts WHERE id=?', [req.params.id])
    res.json({ ok: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
