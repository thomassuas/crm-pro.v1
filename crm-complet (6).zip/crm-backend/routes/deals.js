const router = require('express').Router()
const db = require('../db')

router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT d.*, CONCAT(c.prenom,' ',c.nom) AS contact_nom, e.nom AS entreprise_nom
      FROM deals d
      LEFT JOIN contacts c    ON d.contact_id    = c.id
      LEFT JOIN entreprises e ON d.entreprise_id = e.id
      ORDER BY FIELD(d.etape,'Prospection','Qualifié','Proposition','Négociation','Gagné','Perdu'), d.valeur DESC
    `)
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.get('/:id', async (req, res) => {
  try {
    const [[row]] = await db.execute('SELECT * FROM deals WHERE id=?', [req.params.id])
    if (!row) return res.status(404).json({ error: 'Introuvable' })
    res.json(row)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.post('/', async (req, res) => {
  try {
    const { nom, valeur, probabilite, etape, contact_id, entreprise_id, responsable, date_cloture } = req.body
    const [r] = await db.execute(
      'INSERT INTO deals (nom,valeur,probabilite,etape,contact_id,entreprise_id,responsable,date_cloture) VALUES (?,?,?,?,?,?,?,?)',
      [nom, valeur||0, probabilite||0, etape||'Prospection', contact_id||null, entreprise_id||null, responsable||null, date_cloture||null]
    )
    const [[created]] = await db.execute('SELECT * FROM deals WHERE id=?', [r.insertId])
    res.status(201).json(created)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.put('/:id', async (req, res) => {
  try {
    const { nom, valeur, probabilite, etape, contact_id, entreprise_id, responsable, date_cloture } = req.body
    await db.execute(
      'UPDATE deals SET nom=?,valeur=?,probabilite=?,etape=?,contact_id=?,entreprise_id=?,responsable=?,date_cloture=? WHERE id=?',
      [nom, valeur||0, probabilite||0, etape, contact_id||null, entreprise_id||null, responsable||null, date_cloture||null, req.params.id]
    )
    const [[updated]] = await db.execute('SELECT * FROM deals WHERE id=?', [req.params.id])
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM deals WHERE id=?', [req.params.id])
    res.json({ ok: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
