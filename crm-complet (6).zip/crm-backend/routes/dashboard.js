const router = require('express').Router()
const db = require('../db')

router.get('/', async (req, res) => {
  try {
    const [[stats]] = await db.execute(`
      SELECT
        (SELECT COUNT(*) FROM contacts)                                        AS nb_contacts,
        (SELECT COUNT(*) FROM deals WHERE etape NOT IN ('Gagné','Perdu'))      AS nb_deals_actifs,
        (SELECT COUNT(*) FROM visites
          WHERE MONTH(date_visite)=MONTH(CURDATE())
            AND YEAR(date_visite)=YEAR(CURDATE()))                            AS visites_ce_mois,
        (SELECT COUNT(*) FROM devis WHERE statut='En attente')                 AS devis_en_attente,
        (SELECT COALESCE(SUM(montant_ht),0) FROM devis WHERE statut='En attente') AS valeur_devis_attente,
        (SELECT COALESCE(SUM(montant_ttc),0) FROM factures WHERE statut='En retard') AS factures_retard
    `)
    res.json(stats)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
