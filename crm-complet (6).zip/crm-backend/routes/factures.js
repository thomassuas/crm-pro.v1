const router = require('express').Router()
const db = require('../db')

router.get('/', async (req, res) => {
  try {
    const { statut } = req.query
    let sql = `
      SELECT f.*, e.nom AS entreprise_nom, dv.reference AS devis_ref,
        f.montant_ht * (1 + f.taux_tva/100) AS montant_ttc
      FROM factures f
      LEFT JOIN entreprises e ON f.entreprise_id = e.id
      LEFT JOIN devis dv      ON f.devis_id = dv.id
    `
    const params = []
    if (statut && statut !== 'tous') { sql += ' WHERE f.statut=?'; params.push(statut) }
    sql += ' ORDER BY f.date_emission DESC'
    const [rows] = await db.execute(sql, params)
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.get('/:id', async (req, res) => {
  try {
    const [[fac]] = await db.execute(
      'SELECT f.*, e.nom AS entreprise_nom, f.montant_ht*(1+f.taux_tva/100) AS montant_ttc FROM factures f LEFT JOIN entreprises e ON f.entreprise_id=e.id WHERE f.id=?',
      [req.params.id]
    )
    if (!fac) return res.status(404).json({ error: 'Introuvable' })
    const [lignes] = await db.execute('SELECT * FROM factures_lignes WHERE facture_id=?', [req.params.id])
    res.json({ ...fac, lignes })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.post('/', async (req, res) => {
  const conn = await db.getConnection()
  try {
    await conn.beginTransaction()
    const { entreprise_id, devis_id, contact_id, statut, date_emission, date_echeance, montant_ht, taux_tva, notes } = req.body
    const [[{ count }]] = await conn.execute('SELECT COUNT(*) AS count FROM factures')
    const reference = `FAC-${String(count + 1).padStart(3, '0')}`
    const [r] = await conn.execute(
      'INSERT INTO factures (reference,devis_id,contact_id,entreprise_id,statut,date_emission,date_echeance,montant_ht,taux_tva,notes) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [reference, devis_id||null, contact_id||null, entreprise_id||null, statut||'En attente', date_emission, date_echeance, montant_ht||0, taux_tva||20, notes||null]
    )
    await conn.commit()
    const [[created]] = await conn.execute(
      'SELECT f.*, e.nom AS entreprise_nom, f.montant_ht*(1+f.taux_tva/100) AS montant_ttc FROM factures f LEFT JOIN entreprises e ON f.entreprise_id=e.id WHERE f.id=?',
      [r.insertId]
    )
    res.status(201).json(created)
  } catch (err) {
    await conn.rollback()
    res.status(500).json({ error: err.message })
  } finally { conn.release() }
})

router.put('/:id/payer', async (req, res) => {
  try {
    await db.execute("UPDATE factures SET statut='Payée', date_paiement=CURDATE() WHERE id=?", [req.params.id])
    const [[updated]] = await db.execute('SELECT * FROM factures WHERE id=?', [req.params.id])
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.put('/:id', async (req, res) => {
  try {
    const { statut, date_paiement } = req.body
    await db.execute('UPDATE factures SET statut=?, date_paiement=? WHERE id=?', [statut, date_paiement||null, req.params.id])
    const [[updated]] = await db.execute('SELECT * FROM factures WHERE id=?', [req.params.id])
    res.json(updated)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM factures WHERE id=?', [req.params.id])
    res.json({ ok: true })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
