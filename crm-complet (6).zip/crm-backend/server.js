require('dotenv').config()
const express = require('express')
const cors    = require('cors')
const db      = require('./db')

const app = express()

// ── CORS — accepte toutes les origines (à restreindre en prod) ──────────────
const corsOptions = {
  origin: '*',
  methods: ['GET','POST','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}
app.use(cors(corsOptions))
app.options('*', cors(corsOptions)) // pre-flight pour toutes les routes
app.use(express.json())

// ── Routes ─────────────────────────────────────────────────────────────────
app.use('/api/dashboard',    require('./routes/dashboard'))
app.use('/api/entreprises',  require('./routes/entreprises'))
app.use('/api/contacts',     require('./routes/contacts'))
app.use('/api/deals',        require('./routes/deals'))
app.use('/api/activites',    require('./routes/activites'))
app.use('/api/visites',      require('./routes/visites'))
app.use('/api/devis',        require('./routes/devis'))
app.use('/api/factures',     require('./routes/factures'))

// ── Health check ────────────────────────────────────────────────────────────
app.get('/api/health', async (req, res) => {
  try {
    await db.execute('SELECT 1')
    res.json({ status: 'ok', db: 'connected', time: new Date().toISOString() })
  } catch (err) {
    res.status(500).json({ status: 'error', message: err.message })
  }
})

// ── 404 handler ─────────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ error: `Route ${req.path} introuvable` }))

// ── Error handler ───────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err)
  res.status(500).json({ error: err.message })
})

// ── Start ───────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 4000
app.listen(PORT, async () => {
  try {
    await db.execute('SELECT 1')
    console.log(`✅  CRM API démarrée sur http://localhost:${PORT}`)
    console.log(`🗄️  MySQL connecté à ${process.env.DB_HOST}/${process.env.DB_NAME}`)
  } catch (err) {
    console.error('❌  Impossible de se connecter à MySQL :', err.message)
    console.error('    Vérifiez votre fichier .env et votre serveur MySQL.')
    process.exit(1)
  }
})
